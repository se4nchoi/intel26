"""
    문제
        계산기 프로그램을 작성하시오.

    요구사항
        1. 숫자와 사칙 연산 사이에 " " 공백이 들어가야 합니다.
        2. 계산식을 split 함수 사용해서 숫자와 문자를 분리 합니다.
        3. 사칙 연산에 조건문이 사용되는 경우 if 문을 사용 합니다.

    출력 예시:
        Case 1)
            계산식을 입력하세요
            1 + 1 (Enter)
            2

        Case 2)
            계산식을 입력하세요
            2 * 3 (Enter)
            6
"""



def main():
    try:
        operand = ["+", "-", "/", "*"]


        # WIP
        pass

    except Exception as error:
        print("오류가 발생하였습니다: ", error)
        exit()

if __name__ == "__main__":
    main()