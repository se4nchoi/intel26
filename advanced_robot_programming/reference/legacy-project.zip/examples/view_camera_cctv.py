"""
view_camera_cctv.py - Live CCTV Viewer with Real-Time 3D Metric Coordinates
Displays live video from the Intel RealSense D435 with interactive 3D coordinate inspection.

Features:
  - Hover mouse anywhere on the screen to view live 3D coordinates (X, Y, Z in mm & cm)
  - Center crosshair always shows distance to the center target
  - Real-time deprojection using camera optical intrinsics
  - Depth Picture-in-Picture (PiP) colormap

Controls:
  [D]         : Toggle Depth Picture-in-Picture (PiP)
  [C]         : Toggle Center Crosshair
  [Q] / [ESC] : Quit Viewer
"""

import cv2
import numpy as np
import time
import pyrealsense2 as rs

# Global mouse coordinates
mouse_x, mouse_y = 320, 240
mouse_inside = False

def on_mouse(event, x, y, flags, param):
    global mouse_x, mouse_y, mouse_inside
    if event == cv2.EVENT_MOUSEMOVE:
        mouse_x = max(0, min(639, x))
        mouse_y = max(0, min(479, y))
        mouse_inside = True

def main():
    print("=========================================================")
    print("      Intel RealSense D435 - 3D CCTV Live Monitor        ")
    print("=========================================================")
    print(" Hover your mouse anywhere on the screen to inspect:")
    print("   X (Horizontal), Y (Vertical), Z (Depth Distance in mm/cm)")
    print(" Controls:")
    print("   [D]         : Toggle Depth PiP")
    print("   [C]         : Toggle Center Crosshair")
    print("   [Q] / [ESC] : Quit")
    print("=========================================================\n")

    # Configure RealSense streams
    pipeline = rs.pipeline()
    config = rs.config()

    width, height, fps = 640, 480, 30
    config.enable_stream(rs.stream.color, width, height, rs.format.bgr8, fps)
    config.enable_stream(rs.stream.depth, width, height, rs.format.z16, fps)

    # Connect with retry mechanism in case USB hub is resetting
    max_retries = 3
    for attempt in range(1, max_retries + 1):
        try:
            profile = pipeline.start(config)
            print("[CCTV] RealSense pipeline active!")
            break
        except Exception as e:
            if attempt < max_retries:
                print(f"[CCTV] Waiting for USB camera (attempt {attempt}/{max_retries})...")
                time.sleep(1.2)
            else:
                print(f"[CCTV] Failed to connect after {max_retries} attempts: {e}")
                print("Tip: If the USB cable was just unplugged, ensure it is firmly connected to a USB 3.0 port.")
                return

    # Align depth to color optical frame
    align = rs.align(rs.stream.color)
    colorizer = rs.colorizer()

    # Get camera intrinsics for accurate 3D metric deprojection
    color_stream = profile.get_stream(rs.stream.color).as_video_stream_profile()
    intrinsics = color_stream.get_intrinsics()

    window_name = "Intel RealSense D435 - Live CCTV Monitor with 3D Coordinates"
    cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(window_name, on_mouse)

    show_pip_depth = True
    show_center_crosshair = True
    prev_time = time.time()
    fps_val = 0.0

    try:
        while True:
            frames = pipeline.wait_for_frames(timeout_ms=5000)
            aligned_frames = align.process(frames)

            color_frame = aligned_frames.get_color_frame()
            depth_frame = aligned_frames.get_depth_frame()

            if not color_frame or not depth_frame:
                continue

            color_img = np.asanyarray(color_frame.get_data())

            # FPS calculation
            curr_time = time.time()
            dt = curr_time - prev_time
            prev_time = curr_time
            if dt > 0:
                fps_val = 0.9 * fps_val + 0.1 * (1.0 / dt)

            # Top CCTV Header Banner
            timestamp_str = time.strftime("%Y-%m-%d %H:%M:%S")
            cv2.rectangle(color_img, (0, 0), (width, 38), (15, 15, 15), -1)
            cv2.putText(color_img, f"REC [LIVE]  {timestamp_str}  |  FPS: {fps_val:.1f}", (15, 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 2)

            # 1. Measure Depth and 3D Coordinates at Mouse Position
            mouse_depth = depth_frame.get_distance(mouse_x, mouse_y)
            if mouse_depth > 0.05:
                # SDK Deprojection: 2D pixel (u,v) + depth (Z) -> 3D metric point (X, Y, Z) in meters
                pt3d = rs.rs2_deproject_pixel_to_point(intrinsics, [mouse_x, mouse_y], mouse_depth)
                x_mm = int(pt3d[0] * 1000)
                y_mm = int(pt3d[1] * 1000)
                z_mm = int(pt3d[2] * 1000)
                z_cm = pt3d[2] * 100.0

                coord_text = f"X:{x_mm:+4d}mm  Y:{y_mm:+4d}mm  Z:{z_mm}mm ({z_cm:.1f}cm)"
                marker_color = (0, 255, 255)
            else:
                coord_text = "Z: Outside Range / Occluded"
                marker_color = (0, 0, 255)

            # Draw crosshair at mouse location
            cv2.drawMarker(color_img, (mouse_x, mouse_y), marker_color, cv2.MARKER_CROSS, 22, 2)

            # Tooltip badge near the mouse
            tooltip_x = max(10, min(width - 290, mouse_x + 15))
            tooltip_y = max(60, min(height - 40, mouse_y - 15))
            cv2.rectangle(color_img, (tooltip_x - 4, tooltip_y - 20), (tooltip_x + 285, tooltip_y + 8), (0, 0, 0), -1)
            cv2.rectangle(color_img, (tooltip_x - 4, tooltip_y - 20), (tooltip_x + 285, tooltip_y + 8), marker_color, 1)
            cv2.putText(color_img, coord_text, (tooltip_x, tooltip_y - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)

            # 2. Measure Center Target Crosshair
            if show_center_crosshair:
                cx, cy = width // 2, height // 2
                center_depth = depth_frame.get_distance(cx, cy)
                cv2.drawMarker(color_img, (cx, cy), (255, 255, 255), cv2.MARKER_TILTED_CROSS, 16, 1)
                if center_depth > 0.05:
                    c_pt = rs.rs2_deproject_pixel_to_point(intrinsics, [cx, cy], center_depth)
                    c_text = f"CENTER: Z={int(c_pt[2]*1000)}mm ({c_pt[2]*100:.1f}cm)"
                else:
                    c_text = "CENTER: --"
                cv2.putText(color_img, c_text, (cx - 75, cy + 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.42, (200, 200, 200), 1)

            # Bottom Status Bar with Instructions
            cv2.rectangle(color_img, (0, height - 28), (width, height), (20, 20, 20), -1)
            cv2.putText(color_img, f"Cursor: ({mouse_x}, {mouse_y})  |  {coord_text}",
                        (15, height - 9), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)

            # 3. Picture-in-Picture Depth Map
            if show_pip_depth:
                depth_colormap_frame = colorizer.colorize(depth_frame)
                depth_colormap = np.asanyarray(depth_colormap_frame.get_data())

                pip_w, pip_h = width // 3, height // 3
                depth_pip = cv2.resize(depth_colormap, (pip_w, pip_h))

                x_offset = width - pip_w - 12
                y_offset = height - pip_h - 35

                cv2.rectangle(color_img, (x_offset - 2, y_offset - 2),
                              (x_offset + pip_w + 2, y_offset + pip_h + 2), (255, 255, 255), 2)
                color_img[y_offset:y_offset + pip_h, x_offset:x_offset + pip_w] = depth_pip
                cv2.putText(color_img, "Depth (PiP)", (x_offset + 5, y_offset + 16),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1)

            cv2.imshow(window_name, color_img)
            key = cv2.waitKey(1) & 0xFF

            if key == ord('q') or key == 27:
                break
            elif key == ord('d'):
                show_pip_depth = not show_pip_depth
            elif key == ord('c'):
                show_center_crosshair = not show_center_crosshair

    finally:
        pipeline.stop()
        cv2.destroyAllWindows()
        print("[CCTV] Viewer closed.")


if __name__ == "__main__":
    main()
