"""
00_safety_and_hardware_diagnostic.py - Non-Destructive Hardware & Safety Check
Performs a zero-motion diagnostic of all cell hardware:
  1. Verifies RealSense D435 camera stream & active intrinsics
  2. Queries Neuromeka Indy robot controller (192.168.3.7) for current pose (NO MOTION)
  3. Checks PLC connectivity (192.168.3.150)
  4. Validates safety floor limits and boundaries
"""

import socket
import subprocess
import time
from neuromeka import IndyDCP3
import pyrealsense2 as rs
from advanced_robot_programming.camera import RealSenseD435


def check_ping(ip: str) -> bool:
    try:
        output = subprocess.run(["ping", "-n", "1", ip], capture_output=True, text=True, timeout=3)
        return output.returncode == 0
    except Exception:
        return False


def main():
    print("===================================================================")
    print("        WORKCELL SAFETY & HARDWARE DIAGNOSTIC (ZERO MOTION)        ")
    print("===================================================================")

    # 1. Camera Diagnostic
    print("\n[1/4] Checking Intel RealSense D435 Depth Camera...")
    ctx = rs.context()
    devices = ctx.query_devices()
    if len(devices) > 0:
        dev = devices[0]
        print(f"  --> Camera Found: {dev.get_info(rs.camera_info.name)}")
        print(f"  --> Serial Number: {dev.get_info(rs.camera_info.serial_number)}")
        print(f"  --> Firmware: {dev.get_info(rs.camera_info.firmware_version)}")
    else:
        print("  --> WARNING: No RealSense camera detected over USB!")

    # 2. Robot Diagnostic (Zero-Motion)
    print("\n[2/4] Checking Neuromeka Robot Controller (192.168.3.7)...")
    if check_ping("192.168.3.7"):
        print("  --> Network Ping: SUCCESS (<1ms)")
        try:
            indy = IndyDCP3("192.168.3.7")
            data = indy.get_control_data()
            p = data.get("p", [0, 0, 0, 0, 0, 0])
            q = data.get("q", [0, 0, 0, 0, 0, 0])
            op_state = data.get("op_state", "Unknown")

            print(f"  --> IndyDCP3 Protocol: CONNECTED!")
            print(f"  --> Operation State: {op_state}")
            print(f"  --> Current Cartesian Pose: X={p[0]:.1f}mm, Y={p[1]:.1f}mm, Z={p[2]:.1f}mm")
            print(f"  --> Current Orientation:    U={p[3]:.1f}deg, V={p[4]:.1f}deg, W={p[5]:.1f}deg")
            print(f"  --> Current Joint Angles:   {[round(j, 1) for j in q]} deg")

            # Floor safety evaluation
            if p[2] < 120.0:
                print("  --> [CAUTION] Robot end-effector is currently close to the table (<120mm)!")
            else:
                print("  --> Table Clearance: SAFE (Current Z > 120mm)")

        except Exception as e:
            print(f"  --> IndyDCP3 Connection Error: {e}")
    else:
        print("  --> Network Ping FAILED for 192.168.3.7!")

    # 3. PLC Diagnostic
    print("\n[3/4] Checking PLC (192.168.3.150)...")
    if check_ping("192.168.3.150"):
        print("  --> Network Ping: SUCCESS (<1ms)")
        # Check port 502
        s = socket.socket()
        s.settimeout(1.0)
        res = s.connect_ex(("192.168.3.150", 502))
        s.close()
        if res == 0:
            print("  --> Modbus TCP Port 502: OPEN & READY")
        else:
            print(f"  --> Port 502 status code: {res} (Verify your PLC project has Modbus TCP server active)")
    else:
        print("  --> Network Ping FAILED for 192.168.3.150!")

    # 4. Safety Golden Rules Checklist
    print("\n[4/4] MANDATORY SAFETY CHECKLIST BEFORE PHYSICAL MOVES:")
    print("  [OK] Always keep 'safety.dry_run: true' in config.yaml for initial tests")
    print("  [OK] Keep velocity ratio <= 10% (safe slow jog)")
    print("  [OK] Keep table crash floor limit 'z_floor_min_mm: 120.0' or higher")
    print("  [OK] Keep your hand near the physical Emergency Stop button on the teach pendant")
    print("  [OK] Clear the robot's working radius of all people and loose objects")
    print("===================================================================\n")


if __name__ == "__main__":
    main()
