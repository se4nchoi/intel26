"""
05_mitsubishi_plc_test.py - Mitsubishi Q03UDVCPU Connection Tester
Tests Ethernet communication to the Mitsubishi Q03UDVCPU at 192.168.3.150.
Supports:
  - MC Protocol (Port 5000, 3E Frame) via pymcprotocol
  - Modbus TCP (Port 502) via pymodbus
"""

import sys
import time

def test_mc_protocol(host="192.168.3.150", port=5010):
    print(f"\n[Test 1] Testing Mitsubishi MC Protocol at {host}:{port}...")
    try:
        import pymcprotocol
        pymc = pymcprotocol.Type3E()
        pymc.setaccessopt(commtype="binary")
        pymc.connect(host, port)
        print(f"  --> SUCCESS: Connected to Q03UDVCPU via MC Protocol!")

        # Read bit M0 (Inspection Trigger)
        m_vals = pymc.batchread_bitunits(headdevice="M0", readsize=8)
        print(f"  --> Read M0-M7: {m_vals}")

        # Read data registers D100-D105
        d_vals = pymc.batchread_wordunits(headdevice="D100", readsize=6)
        print(f"  --> Read D100-D105: {d_vals}")

        # Test writing operation ID 1 to D100
        pymc.batchwrite_wordunits(headdevice="D100", values=[1])
        print(f"  --> Test write to D100=1: SUCCESS")

        pymc.close()
        return True
    except Exception as e:
        print(f"  --> MC Protocol Connection Result: {e}")
        print("      (Check GX Works2 Built-in Ethernet Open Setting -> MC Protocol Port 5000)")
        return False


def test_modbus_tcp(host="192.168.3.150", port=502):
    print(f"\n[Test 2] Testing Modbus TCP at {host}:{port}...")
    try:
        from pymodbus.client import ModbusTcpClient
        client = ModbusTcpClient(host, port=port, timeout=1.5)
        if client.connect():
            print(f"  --> SUCCESS: Connected to PLC via Modbus TCP!")
            res = client.read_coils(address=0, count=4)
            if not res.is_error():
                print(f"  --> Read Coils 0-3: {res.bits[:4]}")
            client.close()
            return True
        else:
            print(f"  --> Could not connect to Port {port} (Port closed or not listening)")
            return False
    except Exception as e:
        print(f"  --> Modbus TCP Error: {e}")
        return False


def main():
    print("=========================================================")
    print("       Mitsubishi Q03UDVCPU PLC Connectivity Tester      ")
    print("=========================================================")
    host = "192.168.3.150"

    # Test MC Protocol (Port 5010)
    mc_ok = test_mc_protocol(host, port=5010)

    # Test Modbus TCP (Port 502)
    mb_ok = test_modbus_tcp(host, port=502)

    print("\nSummary:")
    print(f"  MC Protocol (Port 5010): {'ONLINE' if mc_ok else 'OFFLINE'}")
    print(f"  Modbus TCP  (Port 502):  {'ONLINE' if mb_ok else 'OFFLINE'}")
    print("=========================================================\n")


if __name__ == "__main__":
    main()
