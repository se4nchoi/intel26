"""
01_camera_live_view.py - Interactive Intel RealSense D435 Explorer
Displays synchronized Color and Depth streams side-by-side with live metric
distance measurement, depth-to-color alignment toggle, and filter controls.

Controls:
  [A] - Toggle Depth-to-Color Alignment
  [F] - Toggle Post-Processing Filters (Spatial, Temporal, Hole Filling)
  [S] - Save Snapshot (Color + Depth colormap)
  [Q] or [ESC] - Exit
"""

import cv2
import numpy as np
import time
from advanced_robot_programming.camera import RealSenseD435

# Global mouse coordinates for interactive depth inspection
mouse_x, mouse_y = 320, 240

def on_mouse(event, x, y, flags, param):
    global mouse_x, mouse_y
    if event == cv2.EVENT_MOUSEMOVE:
        # If hovering over the right panel (depth), map back to single frame coordinates
        mouse_x = x % 640
        mouse_y = min(479, y)

def main():
    print("=========================================================")
    print("       Intel RealSense D435 - Live Stream Explorer       ")
    print("=========================================================")
    print(" Hotkeys:")
    print("   [A] : Toggle Depth-to-Color Alignment")
    print("   [F] : Toggle Depth Post-Processing Filters")
    print("   [S] : Save image snapshot")
    print("   [Q] : Quit")
    print("=========================================================")

    align_enabled = True
    filters_enabled = True

    camera = RealSenseD435(
        width=640,
        height=480,
        fps=30,
        align_to_color=align_enabled,
        enable_filters=filters_enabled
    )

    if not camera.start():
        print("Failed to initialize RealSense camera.")
        return

    window_name = "RealSense D435: Color (Left) vs Depth (Right)"
    cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(window_name, on_mouse)

    prev_time = time.time()
    fps = 0.0

    try:
        while True:
            color_img, depth_meters, depth_colormap, depth_frame = camera.get_frames(
                apply_filters=filters_enabled
            )

            if color_img is None or depth_meters is None:
                time.sleep(0.01)
                continue

            # Calculate FPS
            curr_time = time.time()
            fps = 0.9 * fps + 0.1 * (1.0 / max(1e-5, (curr_time - prev_time)))
            prev_time = curr_time

            # Query 3D coordinate at mouse position
            point_3d = camera.get_3d_point(mouse_x, mouse_y, depth_frame=depth_frame)
            dist_text = "N/A"
            if point_3d is not None:
                dist_m = point_3d[2]
                dist_text = f"X:{point_3d[0]:.3f}m Y:{point_3d[1]:.3f}m Z:{dist_m:.3f}m ({int(dist_m*1000)}mm)"
            elif depth_meters[mouse_y, mouse_x] > 0:
                dist_m = depth_meters[mouse_y, mouse_x]
                dist_text = f"Dist: {dist_m:.3f}m ({int(dist_m*1000)}mm)"

            # Draw crosshairs on both color and depth images
            for img in [color_img, depth_colormap]:
                cv2.drawMarker(img, (mouse_x, mouse_y), (0, 255, 0), cv2.MARKER_CROSS, 20, 2)

            # Overlay HUD status on Color Image
            hud_color = (0, 255, 255)
            cv2.putText(color_img, f"FPS: {fps:.1f}", (15, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, hud_color, 2)
            cv2.putText(color_img, f"Alignment: {'ON (Color Frame)' if align_enabled else 'OFF (IR Frame)'}", (15, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0) if align_enabled else (0, 0, 255), 1)
            cv2.putText(color_img, f"Filters: {'ON' if filters_enabled else 'OFF'}", (15, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0) if filters_enabled else (0, 0, 255), 1)
            cv2.putText(color_img, f"Cursor @ ({mouse_x}, {mouse_y}): {dist_text}", (15, 105), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)

            # Combine Color and Depth side-by-side
            combined_view = np.hstack((color_img, depth_colormap))

            cv2.imshow(window_name, combined_view)
            key = cv2.waitKey(1) & 0xFF

            if key == ord('q') or key == 27:  # 'q' or ESC
                break
            elif key == ord('f'):  # Toggle filters
                filters_enabled = not filters_enabled
                camera.enable_filters = filters_enabled
                print(f"[Controls] Depth Filters: {'ENABLED' if filters_enabled else 'DISABLED'}")
            elif key == ord('a'):  # Toggle alignment
                align_enabled = not align_enabled
                camera.stop()
                camera = RealSenseD435(
                    width=640,
                    height=480,
                    fps=30,
                    align_to_color=align_enabled,
                    enable_filters=filters_enabled
                )
                camera.start()
                print(f"[Controls] Alignment to Color: {'ENABLED' if align_enabled else 'DISABLED'}")
            elif key == ord('s'):  # Save snapshot
                timestamp = int(time.time())
                color_file = f"snapshot_color_{timestamp}.png"
                depth_file = f"snapshot_depth_{timestamp}.png"
                cv2.imwrite(color_file, color_img)
                cv2.imwrite(depth_file, depth_colormap)
                print(f"[Snapshot] Saved {color_file} and {depth_file}")

    except KeyboardInterrupt:
        pass
    finally:
        camera.stop()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
