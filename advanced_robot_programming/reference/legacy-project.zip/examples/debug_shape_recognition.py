"""
debug_shape_recognition.py - Interactive Shape Recognition Diagnostics
Inspects why an object is recognized as a Cube vs Cylinder in real-time.
Displays 2D contour metrics and 3D depth surface curvature live.

Press [Q] or [ESC] to exit.
"""

import cv2
import numpy as np
import time
from advanced_robot_programming.camera import RealSenseD435
from advanced_robot_programming.proxy_classifier import ProxyClassifier


def main():
    print("=========================================================")
    print("       Shape Recognition Live Diagnostic & Tuner         ")
    print("=========================================================")
    print(" Move your Blue Cube and Blue Cylinder in front of camera.")
    print(" Press [Q] or [ESC] to quit.")
    print("=========================================================\n")

    camera = RealSenseD435(width=640, height=480, fps=30, align_to_color=True)
    if not camera.start():
        print("Camera start failed.")
        return

    classifier = ProxyClassifier(min_contour_area=800)
    window_name = "Shape Diagnostic: Cube vs Cylinder"
    cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)

    try:
        while True:
            color_img, depth_meters, _, depth_frame = camera.get_frames()
            if color_img is None:
                time.sleep(0.01)
                continue

            det, annotated = classifier.classify_frame(color_img, depth_meters)

            # Draw Diagnostic Dashboard at top-left
            cv2.rectangle(annotated, (10, 10), (440, 160), (20, 20, 20), -1)
            cv2.rectangle(annotated, (10, 10), (440, 160), (100, 100, 100), 1)

            if det:
                shape = det["shape"]
                badge_col = (0, 255, 0) if shape == "Cylinder" else (0, 200, 255)

                cv2.putText(annotated, f"VERDICT: {det['label'].upper()}", (20, 40),
                            cv2.FONT_HERSHEY_DUPLEX, 0.75, badge_col, 2)
                cv2.putText(annotated, f"1. Rect Fill Ratio:   {det['rect_fill']:.2f} (Cube >=0.90, Cyl <0.88)",
                            (20, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
                cv2.putText(annotated, f"2. Circularity:       {det['circularity']:.2f} (End disc >0.80)",
                            (20, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
                cv2.putText(annotated, f"3. Depth Curvature dZ:{det['depth_curve_mm']:+.1f} mm (Cyl >+2.5mm, Cube ~0)",
                            (20, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
                cv2.putText(annotated, f"4. Approx Vertices:   {det['vertices']} corners",
                            (20, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
            else:
                cv2.putText(annotated, "NO OBJECT DETECTED", (20, 50),
                            cv2.FONT_HERSHEY_DUPLEX, 0.7, (0, 0, 255), 2)
                cv2.putText(annotated, "Place a Red/Blue Cube or Cylinder in view", (20, 85),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.48, (200, 200, 200), 1)

            cv2.imshow(window_name, annotated)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q') or key == 27:
                break

    finally:
        camera.stop()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
