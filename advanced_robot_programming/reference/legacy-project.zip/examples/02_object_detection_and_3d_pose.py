"""
02_object_detection_and_3d_pose.py - 3D Object Localization with OpenCV & RealSense
Detects objects based on color/shape, extracts their 2D image coordinates,
and deprojects them into 3D metric camera coordinates (X_c, Y_c, Z_c) in meters/millimeters.

Demonstrates how vision classifies objects into different Operation Types:
  - Red Object   -> Operation 1: Sort to Station A
  - Blue Object  -> Operation 2: Sort to Station B
  - Green Object -> Operation 3: Quality Reject Bin
"""

import cv2
import numpy as np
import time
from typing import List, Dict
from advanced_robot_programming.camera import RealSenseD435


# HSV Color Ranges for segmentation
COLOR_RANGES = {
    "Red": [
        # Red wraps around HSV 0/180
        (np.array([0, 100, 70]), np.array([10, 255, 255])),
        (np.array([170, 100, 70]), np.array([180, 255, 255]))
    ],
    "Blue": [
        (np.array([100, 120, 70]), np.array([130, 255, 255]))
    ],
    "Green": [
        (np.array([35, 80, 70]), np.array([85, 255, 255]))
    ]
}

# Operation code mappings based on classification
OPERATION_MAPPINGS = {
    "Red": {"op_id": 1, "action": "Sort to Station A (Red Pallet)", "color_bgr": (0, 0, 255)},
    "Blue": {"op_id": 2, "action": "Sort to Station B (Blue Pallet)", "color_bgr": (255, 0, 0)},
    "Green": {"op_id": 3, "action": "Reject to Quality Bin", "color_bgr": (0, 255, 0)}
}


def detect_objects_and_poses(
    color_img: np.ndarray,
    depth_meters: np.ndarray,
    camera: RealSenseD435,
    min_area: int = 500
) -> List[Dict]:
    """
    Detects colored objects in the scene and calculates their 3D centroids.
    """
    hsv = cv2.cvtColor(color_img, cv2.COLOR_BGR2HSV)
    detected_objects = []

    for color_name, ranges in COLOR_RANGES.items():
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for lower, upper in ranges:
            mask = cv2.bitwise_or(mask, cv2.inRange(hsv, lower, upper))

        # Morphological filtering to eliminate noise
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < min_area:
                continue

            # Compute 2D centroid (u, v)
            M = cv2.moments(cnt)
            if M["m00"] == 0:
                continue
            u = int(M["m10"] / M["m00"])
            v = int(M["m01"] / M["m00"])

            # Bounding box
            x, y, w, h = cv2.boundingRect(cnt)

            # Robust depth measurement using median of ROI
            z_depth = camera.get_roi_depth(depth_meters, x, y, w, h)

            # Deproject (u, v, z) to 3D camera metric space (X, Y, Z)
            point_3d = camera.get_3d_point(u, v, depth_val=z_depth)

            op_info = OPERATION_MAPPINGS.get(color_name, {"op_id": 0, "action": "Unknown", "color_bgr": (255, 255, 255)})

            detected_objects.append({
                "class": color_name,
                "operation_id": op_info["op_id"],
                "action": op_info["action"],
                "color_bgr": op_info["color_bgr"],
                "u": u,
                "v": v,
                "bbox": (x, y, w, h),
                "area": area,
                "point_3d": point_3d  # [X, Y, Z] in meters
            })

    return detected_objects


def main():
    print("=========================================================")
    print("      RealSense D435 + OpenCV 3D Object Localizer        ")
    print("=========================================================")
    print(" Press [Q] or [ESC] to quit.")
    print(" Demonstrating 2D image coordinates -> 3D camera space   ")
    print(" and automatic Operation dispatch based on recognized class.")
    print("=========================================================")

    camera = RealSenseD435(width=640, height=480, fps=30, align_to_color=True)
    if not camera.start():
        print("Camera initialization failed.")
        return

    window_name = "3D Object Detection & Operation Dispatch"
    cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)

    try:
        while True:
            color_img, depth_meters, depth_colormap, depth_frame = camera.get_frames()
            if color_img is None:
                time.sleep(0.01)
                continue

            display_img = color_img.copy()

            # Run detection
            objects = detect_objects_and_poses(color_img, depth_meters, camera)

            # Draw detections
            for idx, obj in enumerate(objects):
                x, y, w, h = obj["bbox"]
                u, v = obj["u"], obj["v"]
                bgr = obj["color_bgr"]
                pt3d = obj["point_3d"]

                # Draw bounding box & centroid
                cv2.rectangle(display_img, (x, y), (x + w, y + h), bgr, 2)
                cv2.circle(display_img, (u, v), 5, (0, 255, 255), -1)

                # Format coordinates
                if pt3d is not None:
                    coord_str = f"3D: [{pt3d[0]:.2f}, {pt3d[1]:.2f}, {pt3d[2]:.2f}]m"
                    mm_str = f"Z={int(pt3d[2]*1000)}mm"
                else:
                    coord_str = "3D: Occluded / No Depth"
                    mm_str = ""

                # Display labels
                label_y = max(20, y - 10)
                cv2.putText(
                    display_img,
                    f"#{idx+1} {obj['class']} (Op {obj['operation_id']})",
                    (x, label_y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    bgr,
                    2
                )
                cv2.putText(
                    display_img,
                    f"{coord_str} {mm_str}",
                    (x, y + h + 18),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.45,
                    (255, 255, 255),
                    1
                )

            # Cell status overlay
            cv2.rectangle(display_img, (10, 10), (330, 80), (0, 0, 0), -1)
            cv2.putText(display_img, f"Detected Objects: {len(objects)}", (15, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.putText(display_img, "RealSense D435 Aligned RGB-D", (15, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
            cv2.putText(display_img, "Press [Q] to exit", (15, 72), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 150), 1)

            cv2.imshow(window_name, display_img)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q') or key == 27:
                break

    finally:
        camera.stop()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
