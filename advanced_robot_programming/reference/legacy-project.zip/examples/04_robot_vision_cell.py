"""
04_robot_vision_cell.py - Integrated Automation Cell Pipeline
Calibrated with Physical Workcell Coordinates & Multi-Layer Palletizer:
  - Pick Location:            [232.49, 514.57, 254.19, -19.52, -179.64, 90.03] mm/deg
  - Pallet Drop Base:         [201.75, 219.29, 304.94, -3.24, -179.44, 90.01] mm/deg
  - Magazine Insert:          [-8.15, 515.98, 343.32, -19.46, -177.65, 90.01] mm/deg
  - Joint Home:               [0.0, 0.0, -90.0, 0.0, -90.0, 0.0] deg

Operations Dispatched by RealSense Vision:
  - Op 1 (Red Part):  Pick & Palletize to 2x2 Grid (Dynamic Slot Indexing 0 -> 7)
  - Op 2 (Blue Part): Pick & Insert into Magazine
  - Op 3 (Green Part): Quality Inspection / Reject
"""

import cv2
import numpy as np
import time
import yaml
from pathlib import Path

from advanced_robot_programming.camera import RealSenseD435
from advanced_robot_programming.robot_controller import IndyRobotController
from advanced_robot_programming.plc_controller import PLCClient
from advanced_robot_programming.vision import detect_objects_and_poses
from advanced_robot_programming.palletizer import Palletizer


# Calibrated Workcell Coordinates
PICK_LOCATION            = [232.49, 514.57, 254.19, -19.52, -179.64, 90.03]
DROP_BASE_LOCATION       = [201.75, 219.29, 304.94, -3.24, -179.44, 90.01]
MAGAZINE_INSERT_LOCATION = [-8.15, 515.98, 343.32, -19.46, -177.65, 90.01]
HOME_JPOS                = [0.0, 0.0, -90.0, 0.0, -90.0, 0.0]


def load_config():
    config_path = Path(__file__).resolve().parent.parent / "config.yaml"
    if config_path.exists():
        with open(config_path, "r") as f:
            return yaml.safe_load(f)
    return {}


def main():
    print("===================================================================")
    print("     Neuromeka Indy + RealSense D435 + PLC Automated Workcell      ")
    print("===================================================================")

    cfg = load_config()
    safety_cfg = cfg.get("safety", {})
    rob_cfg = cfg.get("robot", {})
    plc_cfg = cfg.get("plc", {})
    pallet_cfg = cfg.get("pallet", {})

    dry_run = safety_cfg.get("dry_run", True)
    max_vel = safety_cfg.get("max_velocity_ratio", 10)
    z_floor = safety_cfg.get("z_floor_min_mm", 150.0)

    print(" Cell Configuration:")
    print(f"   - Robot IP:       {rob_cfg.get('robot_ip', '192.168.3.7')}")
    print(f"   - PLC IP:         {plc_cfg.get('host', '192.168.3.150')}")
    print(f"   - Safety Mode:    {'DRY-RUN (Safe Air Moves Only)' if dry_run else 'LIVE PHYSICAL MOTION'}")
    print(f"   - Max Speed:      {max_vel}%")
    print(f"   - Safety Floor:   {z_floor} mm")
    print("===================================================================\n")

    # 1. Initialize Palletizer (2x2 grid, 2 layers, offset 80mm, layer height 30mm)
    palletizer = Palletizer(
        base_location=DROP_BASE_LOCATION,
        grid_x=pallet_cfg.get("grid_x", 2),
        grid_y=pallet_cfg.get("grid_y", 2),
        max_floors=pallet_cfg.get("max_floors", 2),
        offset_x=pallet_cfg.get("offset_x", 80.0),
        offset_y=pallet_cfg.get("offset_y", 80.0),
        layer_height=pallet_cfg.get("layer_height", 30.0)
    )

    # 2. Initialize RealSense Camera
    camera = RealSenseD435(width=640, height=480, fps=30, align_to_color=True)
    camera.start()

    # 3. Initialize Robot Controller with Safety Bounds
    robot = IndyRobotController(
        robot_ip=rob_cfg.get("robot_ip", "192.168.3.7"),
        index=0,
        allow_mock_fallback=True,
        dry_run=dry_run,
        max_vel_ratio=max_vel,
        x_limits_mm=safety_cfg.get("x_limits_mm", [-50.0, 650.0]),
        y_limits_mm=safety_cfg.get("y_limits_mm", [100.0, 650.0]),
        z_limits_mm=[z_floor, 650.0],
        home_jpos=HOME_JPOS,
        default_tool_orientation=PICK_LOCATION[3:]
    )
    robot.connect()

    # 4. Initialize PLC Client (Mitsubishi Q MC Protocol on port 5010)
    plc = PLCClient(
        host=plc_cfg.get("host", "192.168.3.150"),
        port=plc_cfg.get("port", 5010),
        protocol=plc_cfg.get("protocol", "mc")
    )
    plc.connect()

    window_name = "Automated Workcell: Vision & Cell Coordinator"
    cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)

    cell_state = "IDLE (WAITING FOR TRIGGER)"
    last_action_desc = "None"

    try:
        while True:
            color_img, depth_meters, _, depth_frame = camera.get_frames()
            if color_img is None:
                time.sleep(0.01)
                continue

            display_img = color_img.copy()

            # Read PLC Trigger / E-Stop
            plc_trigger = plc.read_trigger(address=0)
            if plc.read_emergency_stop():
                cv2.putText(display_img, "EMERGENCY STOP!", (50, 240), cv2.FONT_HERSHEY_DUPLEX, 1.0, (0, 0, 255), 3)
                cv2.imshow(window_name, display_img)
                cv2.waitKey(100)
                continue

            # Draw HUD
            cv2.rectangle(display_img, (10, 10), (520, 120), (30, 30, 30), -1)
            cv2.putText(display_img, f"Cell State: {cell_state}", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2)
            cv2.putText(display_img, f"Trigger (PLC/Space): {'ACTIVE' if plc_trigger else 'WAITING'}", (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0) if plc_trigger else (200, 200, 200), 1)
            cv2.putText(display_img, f"Pallet Fill: {palletizer.current_item_count} / {palletizer.total_max_items} slots", (20, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 200, 100), 1)
            cv2.putText(display_img, f"Last: {last_action_desc}", (20, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)

            cv2.imshow(window_name, display_img)
            key = cv2.waitKey(10) & 0xFF

            manual_trigger = (key == 32)  # [SPACE]
            if key == ord('q') or key == 27:
                break
            elif key == ord('h'):
                robot.move_home()
            elif key == ord('r'):
                palletizer.reset()
                print("[Palletizer] Counter reset to 0.")

            # Trigger inspection cycle
            if plc_trigger or manual_trigger:
                print("\n=======================================================")
                print(f"[Cycle Start] Trigger received (PLC: {plc_trigger}, Manual: {manual_trigger})")
                cell_state = "VISION INSPECTION"
                plc.set_vision_busy(True)
                plc.set_trigger_simulation(0, False)

                time.sleep(0.1)
                color_img, depth_meters, _, _ = camera.get_frames()

                detected = detect_objects_and_poses(color_img, depth_meters, camera)

                # Default to Op 1 if nothing detected during simulation/test
                if len(detected) == 0:
                    print("[Vision] Note: No object in view. Using default Operation 1 (Palletize).")
                    target_class = "Simulated Part"
                    op_id = 1
                else:
                    target_class = detected[0]["class"]
                    op_id = detected[0]["operation_id"]

                # Determine Pick & Place targets based on recognized Operation
                pick_pose = list(PICK_LOCATION)

                if op_id == 1:
                    # Operation 1: Palletize to 2x2 grid (Floor 0 & Floor 1)
                    slot_idx, drop_pose, is_full = palletizer.get_next_drop_pose()
                    op_desc = f"Op 1: Palletize ({target_class}) -> Slot #{slot_idx+1} [Floor {slot_idx//4}]"
                    print(f"[Cell] {op_desc}")
                    if is_full:
                        print("[Cell] Pallet is now FULL (8/8 items)!")
                elif op_id == 2:
                    # Operation 2: Insert into Magazine
                    drop_pose = list(MAGAZINE_INSERT_LOCATION)
                    op_desc = f"Op 2: Insert into Magazine ({target_class})"
                    print(f"[Cell] {op_desc}")
                else:
                    # Operation 3: Quality Reject
                    drop_pose = [DROP_BASE_LOCATION[0], DROP_BASE_LOCATION[1] + 160.0, DROP_BASE_LOCATION[2], -3.24, -179.44, 90.01]
                    op_desc = f"Op 3: Quality Reject ({target_class})"
                    print(f"[Cell] {op_desc}")

                # Dispatch data to PLC registers
                plc.write_operation_result(
                    operation_id=op_id,
                    confidence=95,
                    x_mm=int(drop_pose[0]),
                    y_mm=int(drop_pose[1]),
                    z_mm=int(drop_pose[2]),
                    error_code=0
                )
                plc.set_vision_busy(False)
                plc.set_vision_done(True)

                # Robot Execution
                cell_state = f"EXECUTING: {op_desc}"
                last_action_desc = op_desc
                plc.set_robot_busy(True)

                robot.execute_pick_and_place(
                    pick_pose=pick_pose,
                    place_pose=drop_pose,
                    approach_height_mm=rob_cfg.get("approach_height_mm", 80.0)
                )

                plc.set_robot_busy(False)
                plc.set_robot_done(True)
                time.sleep(0.3)
                plc.set_robot_done(False)
                plc.set_vision_done(False)

                cell_state = "IDLE (WAITING FOR TRIGGER)"
                print(f"[Cycle Complete] Successfully executed {op_desc}")
                print("=======================================================\n")

    finally:
        camera.stop()
        plc.disconnect()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
