"""
03_plc_modbus_server_mock.py - Industrial PLC Simulator (Modbus TCP)
Simulates a PLC controlling a conveyor / assembly line station.
Allows testing the robot-vision-PLC handshake protocol locally without hardware.

Listens on: 127.0.0.1:5020
Interactive Console:
  [T] + Enter : Trigger Inspection (simulate part sensor tripping)
  [E] + Enter : Toggle Emergency Stop / Safety Gate
  [S] + Enter : Print Register & Coil Status Table
  [Q] + Enter : Stop Simulator
"""

import asyncio
import threading
import sys
import time

from pymodbus.server import StartAsyncTcpServer
from pymodbus.datastore import (
    ModbusSequentialDataBlock,
    ModbusServerContext,
    ModbusDeviceContext
)

# Global datastore context
store_context = None

def setup_server_context():
    # Coils (0 - 99)
    # 0: Trigger, 1: E-Stop, 10: Vision Busy, 11: Vision Done, 12: Robot Busy, 13: Robot Done
    coils = ModbusSequentialDataBlock(0, [False] * 100)

    # Holding Registers (0 - 199)
    # 100: Operation ID, 101: Confidence, 102: X (mm), 103: Y (mm), 104: Z (mm), 105: Error
    registers = ModbusSequentialDataBlock(0, [0] * 200)

    device_context = ModbusDeviceContext(
        di=coils,
        co=coils,
        hr=registers,
        ir=registers
    )

    context = ModbusServerContext(devices=device_context, single=True)
    return context

def print_status():
    if store_context is None:
        return
    dev = store_context[0]

    # Read coils
    trigger = dev.getValues(1, 0, 1)[0]
    estop = dev.getValues(1, 1, 1)[0]
    vis_busy = dev.getValues(1, 10, 1)[0]
    vis_done = dev.getValues(1, 11, 1)[0]
    rob_busy = dev.getValues(1, 12, 1)[0]
    rob_done = dev.getValues(1, 13, 1)[0]

    # Read registers
    regs = dev.getValues(3, 100, 6)
    op_id, conf, x_raw, y_raw, z_raw, err = regs

    # Unpack signed 16-bit
    def to_signed16(n):
        return n - 0x10000 if n > 32767 else n

    x_mm, y_mm, z_mm = to_signed16(x_raw), to_signed16(y_raw), to_signed16(z_raw)

    print("\n------------------ [PLC Simulator Status] ------------------")
    print(f" Signals (Coils):")
    print(f"   [Coil  0] Trigger Inspection: {'ACTIVE (1)' if trigger else 'OFF (0)'}")
    print(f"   [Coil  1] Emergency Stop:     {'TRIPPED (1)' if estop else 'CLEAR (0)'}")
    print(f"   [Coil 10] Vision Busy:        {'BUSY (1)' if vis_busy else 'IDLE (0)'}")
    print(f"   [Coil 11] Vision Done:        {'DONE (1)' if vis_done else 'IDLE (0)'}")
    print(f"   [Coil 12] Robot Busy:         {'BUSY (1)' if rob_busy else 'IDLE (0)'}")
    print(f"   [Coil 13] Robot Done:         {'DONE (1)' if rob_done else 'IDLE (0)'}")
    print(f" Data (Holding Registers):")
    print(f"   [Reg 100] Operation ID:       {op_id}")
    print(f"   [Reg 101] Confidence:         {conf}%")
    print(f"   [Reg 102-104] Pick Coord:     X={x_mm}mm, Y={y_mm}mm, Z={z_mm}mm")
    print(f"   [Reg 105] Error Code:         {err}")
    print("------------------------------------------------------------\n")


def console_input_loop():
    time.sleep(1.0)
    print("\n[PLC Simulator] Ready! Available Commands:")
    print("  't' + Enter : Trigger inspection (simulate part arrived)")
    print("  'e' + Enter : Toggle E-Stop")
    print("  's' + Enter : Display status registers")
    print("  'q' + Enter : Quit\n")

    dev = store_context[0]
    while True:
        try:
            cmd = input().strip().lower()
            if cmd == 't':
                dev.setValues(1, 0, [True])
                print("[PLC Simulator] Sensor triggered! Coil 0 = 1 (Part present).")
            elif cmd == 'e':
                curr = dev.getValues(1, 1, 1)[0]
                dev.setValues(1, 1, [not curr])
                print(f"[PLC Simulator] E-Stop is now {'TRIGGERED' if not curr else 'CLEARED'}.")
            elif cmd == 's':
                print_status()
            elif cmd == 'q':
                print("[PLC Simulator] Exiting...")
                sys.exit(0)
        except (EOFError, KeyboardInterrupt):
            break


async def run_server():
    global store_context
    store_context = setup_server_context()

    # Start console thread
    threading.Thread(target=console_input_loop, daemon=True).start()

    print("[PLC Simulator] Modbus TCP Server running on 127.0.0.1:5020")
    await StartAsyncTcpServer(
        context=store_context,
        address=("127.0.0.1", 5020)
    )


def main():
    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        print("\nServer stopped.")


if __name__ == "__main__":
    main()
