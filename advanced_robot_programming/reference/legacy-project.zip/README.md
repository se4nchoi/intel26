# Advanced Robot Programming: Neuromeka Indy + Intel RealSense D435 + PLC

An integrated experimental framework for vision-guided industrial robotics using **Python 3.12**, **uv**, **Neuromeka Indy** collaborative robots, **Intel RealSense D435** depth cameras, and **Industrial PLCs (Modbus TCP)**.

---

## 📦 Environment Setup (uv & Python 3.12)

This repository is managed with `uv` and Python 3.12. All dependencies are pre-configured in [pyproject.toml](file:///e:/_se4nchoi/intel26/advanced_robot_programming/pyproject.toml).

### Installed Libraries:
- `neuromeka (v3.4.2.2)`: Neuromeka Indy robot client library (`IndyDCP3`)
- `pyrealsense2 (v2.58.4)`: Official Intel RealSense SDK Python bindings
- `opencv-python (v4.11.0)`: Computer Vision and image processing
- `pymodbus (v3.15.0)`: Modbus TCP/RTU industrial PLC communication
- `numpy (v1.26.4)`: High-performance numerical computations

To verify your environment anytime:
```bash
uv run python -c "import neuromeka, pyrealsense2, cv2, pymodbus; print('All libraries OK!')"
```

---

## 📚 Technical Documentation

Detailed guides are provided in the `docs/` folder:
1. [docs/01_how_realsense_d435_works.md](file:///e:/_se4nchoi/intel26/advanced_robot_programming/docs/01_how_realsense_d435_works.md):
   - Active Infrared Stereo Vision physics ($Z = \frac{f \cdot B}{d}$).
   - Left/Right IR imagers, IR dot projector, and RGB sensor.
   - Depth-to-Color alignment (`rs.align`) and 2D pixel to 3D metric camera space deprojection.
   - Real-time post-processing filters (Spatial, Temporal, Hole Filling).
2. [docs/02_plc_robot_vision_integration.md](file:///e:/_se4nchoi/intel26/advanced_robot_programming/docs/02_plc_robot_vision_integration.md):
   - System topology and communication protocols (Modbus TCP, IndyDCP3).
   - The industrial handshake state machine (Trigger $\rightarrow$ Inspect $\rightarrow$ Classify $\rightarrow$ Execute $\rightarrow$ Done).
   - Hand-Eye calibration transformation matrix ($^{Robot}T_{Camera}$).
   - Dynamic operation selection from visual classification.

---

## 🚀 Hands-on Examples

### 1. RealSense D435 Live Stream & Depth Inspector
Inspect live color and depth streams, measure real-world distance at the crosshair, and toggle filters:
```bash
uv run python examples/01_camera_live_view.py
```
- **Hotkeys:**
  - `[A]`: Toggle Depth-to-Color alignment.
  - `[F]`: Toggle Spatial & Temporal depth smoothing filters.
  - `[S]`: Save a snapshot of Color + Depth maps.
  - `[Q]`: Quit.

---

### 2. OpenCV 3D Object Localization & Operation Dispatch
Detects colored objects in the camera view and calculates their exact real-world 3D camera coordinates $(X_c, Y_c, Z_c)$:
```bash
uv run python examples/02_object_detection_and_3d_pose.py
```
- Red objects $\rightarrow$ **Operation 1** (Station A Pallet)
- Blue objects $\rightarrow$ **Operation 2** (Station B Pallet)
- Green objects $\rightarrow$ **Operation 3** (Quality Reject Bin)

---

### 3. Industrial PLC Modbus Simulator
Runs a local Modbus TCP server on `127.0.0.1:5020` to simulate a physical PLC:
```bash
uv run python examples/03_plc_modbus_server_mock.py
```
- Type `t` + Enter: Simulate part sensor triggering an inspection cycle.
- Type `e` + Enter: Toggle Emergency Stop / Safety Gate.
- Type `s` + Enter: Inspect current coil signals and holding registers.

---

### 4. Integrated Cell Orchestrator (Camera + Vision + PLC + Robot)
The complete end-to-end industrial workcell pipeline:
```bash
uv run python examples/04_robot_vision_cell.py
```
- Automatically connects to your connected **Intel RealSense D435**.
- Connects to the PLC (or built-in mock).
- Connects to the Neuromeka robot via `IndyDCP3` (or simulated mock mode if offline).
- Press `[SPACE]` in the camera window to manually trigger an inspection cycle!

---

## ⚙️ Configuration

Tune IP addresses, camera resolutions, and calibration offsets in [config.yaml](file:///e:/_se4nchoi/intel26/advanced_robot_programming/config.yaml):
- `robot.robot_ip`: Neuromeka controller IP (e.g. `192.168.0.10`)
- `plc.host` / `plc.port`: PLC Modbus TCP connection
- `calibration.camera_position_in_robot_base`: Optical center position relative to robot base origin.
