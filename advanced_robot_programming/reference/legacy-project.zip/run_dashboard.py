"""
run_dashboard.py - Launch the Workcell Web Dashboard
Starts the FastAPI web server on http://localhost:9000.
Connects to Neuromeka Indy (192.168.3.7) via TCP,
streams the RealSense D435 camera with Proxy Object Recognition,
and tracks 2D Multi-Floor Palletizer status.
"""

from advanced_robot_programming.web.server import main

if __name__ == "__main__":
    main()
