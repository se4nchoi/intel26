"""
proxy_classifier.py - Advanced Proxy Object Recognition (Cube vs Cylinder, Red vs Blue)
Uses Multi-Modal Classification:
  1. 2D Contour Geometry (Aspect ratio, rectangular fill ratio, corner sharpness)
  2. 3D Depth Surface Curvature (Cylinder surface bulges forward; Cube face is planar)
  3. Top/Side Edge Curvature (Elliptical ends vs Flat edges)
"""

from typing import Tuple, Dict, Optional, List
import numpy as np
import cv2

# HSV Color Ranges for Red and Blue
COLOR_THRESHOLDS = {
    "Red": [
        (np.array([0, 100, 60]), np.array([12, 255, 255])),
        (np.array([168, 100, 60]), np.array([180, 255, 255]))
    ],
    "Blue": [
        (np.array([90, 90, 50]), np.array([135, 255, 255]))
    ]
}


class ProxyClassifier:
    """
    Classifies proxy objects into Cube vs Cylinder and Red vs Blue.
    Combines 2D geometry and RealSense 3D depth curvature.
    """

    def __init__(self, min_contour_area: int = 1000):
        self.min_contour_area = min_contour_area

    def classify_frame(
        self, color_img: np.ndarray, depth_meters: Optional[np.ndarray] = None
    ) -> Tuple[Optional[Dict], np.ndarray]:
        annotated = color_img.copy()
        hsv = cv2.cvtColor(color_img, cv2.COLOR_BGR2HSV)

        best_detection = None
        max_area = 0

        best_cnt = None
        for color_name, ranges in COLOR_THRESHOLDS.items():
            mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
            for lower, upper in ranges:
                mask = cv2.bitwise_or(mask, cv2.inRange(hsv, lower, upper))

            # Morphological cleanup
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area < self.min_contour_area:
                    continue

                if area > max_area:
                    max_area = area
                    best_cnt = cnt
                    best_detection = self._analyze_shape(
                        cnt, area, color_name, color_img, depth_meters
                    )

        # Draw annotations
        if best_detection and best_cnt is not None:
            x, y, w, h = best_detection["bbox"]
            color_bgr = (0, 0, 255) if best_detection["color"] == "Red" else (255, 120, 0)

            # Bounding box
            cv2.rectangle(annotated, (x, y), (x + w, y + h), color_bgr, 3)

            # Convex hull overlay
            hull = cv2.convexHull(best_cnt)
            cv2.drawContours(annotated, [hull], -1, (0, 255, 0), 1)

            # Details banner
            shape = best_detection["shape"]
            label = f"{best_detection['color']} {shape}"
            op_id = best_detection["operation_id"]
            metric_str = (
                f"Fill:{best_detection['rect_fill']:.2f} | "
                f"Circ:{best_detection['circularity']:.2f} | "
                f"dZ:{best_detection['depth_curve_mm']:+.1f}mm"
            )

            cv2.rectangle(annotated, (x, max(0, y - 50)), (x + 360, y), (15, 15, 15), -1)
            cv2.putText(annotated, f"PROXY: {label} -> OP {op_id}", (x + 6, max(18, y - 28)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.58, (0, 255, 255), 2)
            cv2.putText(annotated, metric_str, (x + 6, max(36, y - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.42, (200, 200, 200), 1)

        return best_detection, annotated

    def _analyze_shape(
        self,
        cnt: np.ndarray,
        area: float,
        color_name: str,
        color_img: np.ndarray,
        depth_meters: Optional[np.ndarray]
    ) -> Dict:
        x, y, w, h = cv2.boundingRect(cnt)
        perimeter = cv2.arcLength(cnt, True)
        circularity = 4 * np.pi * (area / (perimeter * perimeter)) if perimeter > 0 else 0.0

        # 1. Rotated Minimum Bounding Box & Rectangular Fill Ratio
        # A cube fills nearly 100% (>0.90) of its minimum bounding rectangle.
        # A cylinder has rounded edges / circular ends that cut corners (fill < 0.88).
        min_rect = cv2.minAreaRect(cnt)
        min_rect_area = max(1.0, min_rect[1][0] * min_rect[1][1])
        rect_fill = area / min_rect_area

        # 2. Polygon Vertex Approximation
        epsilon = 0.03 * perimeter
        approx = cv2.approxPolyDP(cnt, epsilon, True)
        vertices = len(approx)

        # 3. 3D Depth Surface Curvature (RealSense Metric Depth)
        # On a cylinder, the center is closer to the camera than the left/right edges (convex arc).
        # On a cube face, depth is planar/flat across the width.
        depth_curve_mm = 0.0
        avg_depth_mm = 0

        if depth_meters is not None:
            roi_depth = depth_meters[y:y+h, x:x+w]
            valid_mask = roi_depth > 0.05
            if np.sum(valid_mask) > 100:
                avg_depth_mm = int(np.median(roi_depth[valid_mask]) * 1000)

                # Sample horizontal middle strip (20% height band)
                mid_y_start = int(h * 0.4)
                mid_y_end = int(h * 0.6)
                strip = roi_depth[mid_y_start:mid_y_end, :]

                # Check horizontal depth profile
                col_depths = []
                for c in range(w):
                    col_vals = strip[:, c]
                    col_valid = col_vals[col_vals > 0.05]
                    if len(col_valid) > 0:
                        col_depths.append((c, np.median(col_valid)))

                if len(col_depths) > 10:
                    # Compare center 20% to left and right 15% edges
                    left_depths = [d for c, d in col_depths if c < w * 0.20]
                    center_depths = [d for c, d in col_depths if w * 0.40 <= c <= w * 0.60]
                    right_depths = [d for c, d in col_depths if c > w * 0.80]

                    if left_depths and center_depths and right_depths:
                        z_edge = (np.mean(left_depths) + np.mean(right_depths)) / 2.0
                        z_mid = np.mean(center_depths)
                        # Positive depth_curve_mm means center bulges forward (cylinder!)
                        depth_curve_mm = (z_edge - z_mid) * 1000.0

        # 4. Multi-Criteria Scoring
        # Cylinder indicators:
        #  - High circularity (>0.80) when looking at circular end
        #  - Rounded ends cutting corners (rect_fill < 0.89)
        #  - Surface depth bulges forward (depth_curve_mm > 2.0mm)
        #  - More vertices from curve approximation (vertices >= 6)
        #
        # Cube indicators:
        #  - High rectangular fill (rect_fill >= 0.90)
        #  - Flat surface (|depth_curve_mm| < 1.8mm)
        #  - 4 distinct sharp corners (vertices == 4)
        cylinder_score = 0.0
        cube_score = 0.0

        # Depth score (Strongest physical signal from 3D camera)
        if depth_curve_mm > 2.5:
            cylinder_score += 3.0  # Clear convex surface
        elif abs(depth_curve_mm) < 1.8:
            cube_score += 2.0      # Flat surface

        # 2D Geometry score
        if circularity > 0.82:
            cylinder_score += 3.0  # End-on circle/disc
        elif circularity < 0.73:
            cube_score += 1.5

        if rect_fill > 0.91:
            cube_score += 2.5      # Crisp rectangle/box
        elif rect_fill < 0.87:
            cylinder_score += 2.0  # Rounded corners

        if vertices == 4:
            cube_score += 2.0
        elif vertices >= 6:
            cylinder_score += 1.5

        # Final Verdict
        if cylinder_score > cube_score:
            shape = "Cylinder"
        else:
            shape = "Cube"

        # Determine Operation:
        # Red Cube      -> Op 1: Palletize to 2x2 Grid
        # Blue Cylinder -> Op 2: Insert into Magazine
        # Red Cylinder  -> Op 1 (or custom)
        # Blue Cube     -> Op 2 (or custom)
        if color_name == "Red" and shape == "Cube":
            op_id = 1
            op_name = "Palletize to 2x2 Grid"
        elif color_name == "Blue" and shape == "Cylinder":
            op_id = 2
            op_name = "Insert into Magazine"
        elif color_name == "Red":
            op_id = 1
            op_name = "Palletize (Red)"
        else:
            op_id = 2
            op_name = "Magazine (Blue)"

        return {
            "color": color_name,
            "shape": shape,
            "label": f"{color_name} {shape}",
            "operation_id": op_id,
            "operation_name": op_name,
            "area": int(area),
            "circularity": round(float(circularity), 2),
            "rect_fill": round(float(rect_fill), 2),
            "depth_curve_mm": round(float(depth_curve_mm), 1),
            "vertices": int(vertices),
            "bbox": (int(x), int(y), int(w), int(h)),
            "depth_mm": int(avg_depth_mm)
        }
