"""
palletizer.py - Multi-layer 2D Pallet Slot Calculation
Computes 3D drop coordinates for multi-floor palletizing grids.
"""

from typing import List, Tuple


class Palletizer:
    """
    Manages multi-layer pallet slot indexing and 3D coordinate calculation.
    
    Default configuration:
      - 2 x 2 grid per floor
      - 2 floors (total 8 items)
      - Row step: -80mm in X
      - Col step: +80mm in Y
      - Floor step: +30mm in Z
    """

    def __init__(
        self,
        base_location: List[float] = [201.75, 219.29, 304.94, -3.24, -179.44, 90.01],
        grid_x: int = 2,           # 2 columns in Y
        grid_y: int = 2,           # 2 rows in X
        max_floors: int = 2,
        offset_x: float = 80.0,    # -X direction
        offset_y: float = 80.0,    # +Y direction
        layer_height: float = 30.0 # +Z direction
    ):
        self.base_location = list(base_location)
        self.grid_x = grid_x
        self.grid_y = grid_y
        self.max_floors = max_floors
        self.slots_per_floor = grid_x * grid_y
        self.total_max_items = self.slots_per_floor * max_floors

        self.offset_x = offset_x
        self.offset_y = offset_y
        self.layer_height = layer_height

        self.current_item_count = 0

    def get_slot_pose(self, item_index: int) -> List[float]:
        """
        Calculates the exact [X, Y, Z, U, V, W] pose for a given item index (0 to 7).
        
        Grid math:
          floor = index // 4
          in_floor = index % 4
          row = in_floor // 2  (along -X)
          col = in_floor % 2   (along +Y)
        """
        floor = (item_index % self.total_max_items) // self.slots_per_floor
        in_floor = item_index % self.slots_per_floor
        row = in_floor // self.grid_x
        col = in_floor % self.grid_x

        target_x = self.base_location[0] - (row * self.offset_x)
        target_y = self.base_location[1] + (col * self.offset_y)
        target_z = self.base_location[2] + (floor * self.layer_height)

        u, v, w = self.base_location[3], self.base_location[4], self.base_location[5]

        return [round(target_x, 2), round(target_y, 2), round(target_z, 2), u, v, w]

    def get_next_drop_pose(self) -> Tuple[int, List[float], bool]:
        """
        Returns (item_index, target_pose, is_pallet_full).
        Increments internal item count.
        """
        idx = self.current_item_count
        pose = self.get_slot_pose(idx)
        self.current_item_count += 1
        is_full = (self.current_item_count >= self.total_max_items)
        if is_full:
            # Wrap around or reset
            self.current_item_count = 0
        return idx, pose, is_full

    def reset(self):
        """Resets pallet count to 0."""
        self.current_item_count = 0
