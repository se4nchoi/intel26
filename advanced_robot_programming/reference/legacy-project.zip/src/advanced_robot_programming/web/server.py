"""
server.py - FastAPI Web Dashboard Server for Robotic Cell Control
Connects to Neuromeka Indy (192.168.3.7) via TCP,
streams RealSense D435 camera feed with Proxy Object Recognition,
and tracks 2D Multi-Floor Palletizer status.
"""

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
import threading
import time
import cv2
import numpy as np
import yaml

from advanced_robot_programming.camera import RealSenseD435
from advanced_robot_programming.robot_controller import IndyRobotController
from advanced_robot_programming.plc_controller import PLCClient
from advanced_robot_programming.palletizer import Palletizer
from advanced_robot_programming.proxy_classifier import ProxyClassifier

# Paths
BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR.parent.parent.parent / "config.yaml"

app = FastAPI(title="Robotic Cell Controller")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# Global Hardware Handlers
config = {}
if CONFIG_PATH.exists():
    with open(CONFIG_PATH, "r") as f:
        config = yaml.safe_load(f)

# Calibrated Positions
PICK_LOCATION = config.get("robot", {}).get("pick_location", [232.49, 514.57, 254.19, -19.52, -179.64, 90.03])
DROP_BASE_LOCATION = config.get("robot", {}).get("drop_base_location", [201.75, 219.29, 304.94, -3.24, -179.44, 90.01])
MAGAZINE_INSERT_LOCATION = config.get("robot", {}).get("magazine_insert_location", [-8.15, 515.98, 343.32, -19.46, -177.65, 90.01])
HOME_JPOS = config.get("robot", {}).get("home_jpos", [0.0, 0.0, -90.0, 0.0, -90.0, 0.0])

# Initialize Devices
palletizer = Palletizer(base_location=DROP_BASE_LOCATION)
proxy_classifier = ProxyClassifier()

robot = IndyRobotController(
    robot_ip="192.168.3.7",
    index=0,
    allow_mock_fallback=True,
    dry_run=True,
    max_vel_ratio=10,
    x_limits_mm=[-50.0, 650.0],
    y_limits_mm=[100.0, 650.0],
    z_limits_mm=[150.0, 650.0],
    home_jpos=HOME_JPOS,
    default_tool_orientation=PICK_LOCATION[3:]
)
robot.connect()

plc = PLCClient(
    host=config.get("plc", {}).get("host", "192.168.3.150"),
    port=config.get("plc", {}).get("port", 5010),
    protocol=config.get("plc", {}).get("protocol", "mc")
)
plc.connect()

camera = RealSenseD435(width=640, height=480, fps=30, align_to_color=True)
camera.start()

# State caches
latest_frame = None
latest_detection = None
frame_lock = threading.Lock()


is_server_running = True


def camera_capture_loop():
    """Background worker continuously pulling frames and running proxy recognition."""
    global latest_frame, latest_detection, is_server_running
    while is_server_running:
        try:
            color_img, depth_meters, _, _ = camera.get_frames()
            if color_img is not None:
                det, annotated = proxy_classifier.classify_frame(color_img, depth_meters)
                with frame_lock:
                    latest_frame = annotated
                    latest_detection = det
            else:
                time.sleep(0.02)
        except Exception:
            time.sleep(0.05)


threading.Thread(target=camera_capture_loop, daemon=True).start()


@app.on_event("shutdown")
def on_shutdown():
    global is_server_running
    print("\n[Server] Shutting down gracefully...")
    is_server_running = False
    camera.stop()
    plc.disconnect()
    print("[Server] Shutdown complete.")


@app.get("/", response_class=HTMLResponse)
async def serve_dashboard():
    html_file = BASE_DIR / "templates" / "index.html"
    return HTMLResponse(content=html_file.read_text(encoding="utf-8"))


@app.get("/video_feed")
async def video_feed():
    """Streams live MJPEG video of the camera with proxy annotations."""
    def generate_frames():
        while is_server_running:
            with frame_lock:
                if latest_frame is not None:
                    ret, buffer = cv2.imencode('.jpg', latest_frame, [cv2.IMWRITE_JPEG_QUALITY, 75])
                    if ret:
                        frame_bytes = buffer.tobytes()
                        yield (b'--frame\r\n'
                               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
            time.sleep(0.033)

    return StreamingResponse(generate_frames(), media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/telemetry")
async def get_telemetry():
    """Returns robot pose, joint angles, proxy detection, and pallet status."""
    rob_status = robot.get_robot_status()
    plc_connected = bool(plc.is_connected and (plc.mc_client is not None or plc.modbus_client is not None))

    det_safe = None
    with frame_lock:
        if latest_detection is not None:
            det_safe = {
                "color": str(latest_detection.get("color", "")),
                "shape": str(latest_detection.get("shape", "")),
                "label": str(latest_detection.get("label", "")),
                "operation_id": int(latest_detection.get("operation_id", 1)),
                "operation_name": str(latest_detection.get("operation_name", "")),
                "circularity": float(latest_detection.get("circularity", 0.0)),
                "rect_fill": float(latest_detection.get("rect_fill", 0.0)),
                "depth_curve_mm": float(latest_detection.get("depth_curve_mm", 0.0)),
                "vertices": int(latest_detection.get("vertices", 0)),
                "bbox": [int(v) for v in latest_detection.get("bbox", (0, 0, 0, 0))],
                "depth_mm": int(latest_detection.get("depth_mm", 0))
            }

    return {
        "robot": rob_status,
        "plc": {
            "is_connected": plc_connected
        },
        "detection": det_safe,
        "pallet": {
            "count": int(palletizer.current_item_count),
            "total": int(palletizer.total_max_items)
        }
    }


@app.post("/api/trigger")
async def trigger_cycle():
    """Executes the Pick-and-Place routine based on the current camera proxy identification."""
    det = latest_detection
    op_id = det["operation_id"] if det else 1
    label = det["label"] if det else "Default (No Object Detected)"

    pick_pose = list(PICK_LOCATION)

    if op_id == 1:
        # Palletize
        slot_idx, drop_pose, is_full = palletizer.get_next_drop_pose()
        op_name = f"Palletized to Slot #{slot_idx + 1} (Floor {slot_idx // 4})"
    elif op_id == 2:
        # Magazine
        drop_pose = list(MAGAZINE_INSERT_LOCATION)
        op_name = "Inserted to Magazine"
    else:
        drop_pose = [DROP_BASE_LOCATION[0], DROP_BASE_LOCATION[1] + 160.0, DROP_BASE_LOCATION[2], -3.24, -179.44, 90.01]
        op_name = "Rejected"

    # Command robot
    robot.execute_pick_and_place(pick_pose=pick_pose, place_pose=drop_pose, approach_height_mm=80.0)

    return {
        "status": "success",
        "operation_id": op_id,
        "detected": label,
        "message": f"Executed {op_name} for proxy: {label}"
    }


@app.post("/api/home")
async def move_home():
    robot.move_home()
    return {"status": "success", "message": "Moved robot to Joint Home."}


@app.post("/api/reset_pallet")
async def reset_pallet():
    palletizer.reset()
    return {"status": "success", "message": "Pallet count reset to 0."}


@app.post("/api/toggle_dryrun")
async def toggle_dryrun():
    robot.dry_run = not robot.dry_run
    return {"status": "success", "dry_run": robot.dry_run}


def main():
    import uvicorn
    port = config.get("dashboard", {}).get("port", 9000)
    print("===================================================================")
    print(f"     Starting Automated Workcell Web Dashboard (Port {port})         ")
    print(f"     Open in your browser: http://localhost:{port}                  ")
    print("===================================================================")
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")


if __name__ == "__main__":
    main()
