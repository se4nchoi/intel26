// app.js - Web Dashboard Controller for Neuromeka Robot + RealSense + Palletizer

let isDryRun = true;

async function updateTelemetry() {
  try {
    const res = await fetch('/api/telemetry');
    if (!res.ok) return;
    const data = await res.json();

    // 1. Robot Telemetry
    const rob = data.robot;
    const robBadge = document.getElementById('robot-conn-badge');
    if (rob.is_connected) {
      robBadge.className = 'badge badge-success';
      robBadge.textContent = rob.is_mock ? 'SIMULATED' : 'ONLINE';
    } else {
      robBadge.className = 'badge badge-warning';
      robBadge.textContent = 'OFFLINE';
    }

    document.getElementById('robot-opstate').textContent = `State: ${rob.op_state}`;
    
    // Cartesian coordinates
    const p = rob.pose || [0, 0, 0, 0, 0, 0];
    document.getElementById('pose-x').textContent = `${p[0].toFixed(1)} mm`;
    document.getElementById('pose-y').textContent = `${p[1].toFixed(1)} mm`;
    document.getElementById('pose-z').textContent = `${p[2].toFixed(1)} mm`;
    document.getElementById('pose-u').textContent = `${p[3].toFixed(1)}°`;
    document.getElementById('pose-v').textContent = `${p[4].toFixed(1)}°`;
    document.getElementById('pose-w').textContent = `${p[5].toFixed(1)}°`;

    // Joint angles
    const q = rob.joints || [0, 0, 0, 0, 0, 0];
    for (let i = 0; i < 6; i++) {
      const el = document.getElementById(`joint-${i+1}`);
      if (el) el.textContent = `${q[i].toFixed(1)}°`;
    }

    // Safety mode
    isDryRun = rob.dry_run;
    const safetyBadge = document.getElementById('safety-mode-badge');
    if (isDryRun) {
      safetyBadge.className = 'badge badge-dryrun';
      safetyBadge.textContent = 'DRY-RUN (AIR ONLY)';
    } else {
      safetyBadge.className = 'badge badge-warning';
      safetyBadge.textContent = 'LIVE PHYSICAL MOTION';
    }

    // 2. PLC Telemetry
    const plcBadge = document.getElementById('plc-conn-badge');
    if (data.plc && data.plc.is_connected) {
      plcBadge.className = 'badge badge-success';
      plcBadge.textContent = 'ONLINE';
    } else {
      plcBadge.className = 'badge badge-subtle';
      plcBadge.textContent = 'DISCONNECTED';
    }

    // 3. Camera Proxy Detection
    const det = data.detection;
    const tagEl = document.getElementById('overlay-tag');
    const iconEl = document.getElementById('proxy-icon');
    const titleEl = document.getElementById('proxy-title');
    const descEl = document.getElementById('proxy-desc');
    const opTagEl = document.getElementById('op-tag');

    if (det && det.label) {
      tagEl.textContent = `DETECTED: ${det.label} (${det.shape})`;
      tagEl.style.color = det.color === 'Red' ? '#f87171' : '#60a5fa';
      
      iconEl.textContent = det.shape === 'Cube' ? '🟥' : '🔵';
      titleEl.textContent = `${det.color} ${det.shape}`;
      descEl.textContent = `Action: ${det.operation_name} (Circularity: ${det.circularity})`;
      
      opTagEl.textContent = `OP ${det.operation_id}`;
      opTagEl.style.background = det.operation_id === 1 ? '#4f46e5' : '#0891b2';
    } else {
      tagEl.textContent = 'Waiting for Proxy Object...';
      tagEl.style.color = '#94a3b8';
      iconEl.textContent = '📦';
      titleEl.textContent = 'No Object In View';
      descEl.textContent = 'Push a sample Red Cube or Blue Cylinder into camera view';
      opTagEl.textContent = 'OP 1';
    }

    // 4. Palletizer Grid
    const pal = data.pallet;
    document.getElementById('pallet-counter').textContent = `${pal.count} / ${pal.total} Items`;
    
    // Update slot styles
    for (let i = 0; i < 8; i++) {
      const slotEl = document.getElementById(`slot-${i}`);
      if (!slotEl) continue;
      slotEl.classList.remove('active-target', 'filled');
      if (i < pal.count) {
        slotEl.classList.add('filled');
      } else if (i === pal.count) {
        slotEl.classList.add('active-target');
      }
    }

  } catch (err) {
    console.error("Telemetry error:", err);
  }
}

// Action button handlers
document.getElementById('btn-trigger').addEventListener('click', async () => {
  const log = document.getElementById('action-status-log');
  log.textContent = "Executing Pick & Place routine...";
  try {
    const res = await fetch('/api/trigger', { method: 'POST' });
    const data = await res.json();
    log.textContent = `Result: ${data.message}`;
    updateTelemetry();
  } catch (e) {
    log.textContent = `Error: ${e.message}`;
  }
});

document.getElementById('btn-home').addEventListener('click', async () => {
  const log = document.getElementById('action-status-log');
  log.textContent = "Moving robot to Joint Home...";
  try {
    const res = await fetch('/api/home', { method: 'POST' });
    const data = await res.json();
    log.textContent = `Result: ${data.message}`;
    updateTelemetry();
  } catch (e) {
    log.textContent = `Error: ${e.message}`;
  }
});

document.getElementById('btn-reset-pallet').addEventListener('click', async () => {
  const log = document.getElementById('action-status-log');
  try {
    const res = await fetch('/api/reset_pallet', { method: 'POST' });
    const data = await res.json();
    log.textContent = `Pallet count reset to 0.`;
    updateTelemetry();
  } catch (e) {
    log.textContent = `Error: ${e.message}`;
  }
});

document.getElementById('btn-toggle-dryrun').addEventListener('click', async () => {
  const log = document.getElementById('action-status-log');
  try {
    const res = await fetch('/api/toggle_dryrun', { method: 'POST' });
    const data = await res.json();
    log.textContent = `Dry-Run Mode is now: ${data.dry_run ? 'ENABLED (Air only)' : 'DISABLED (Live picks)'}`;
    updateTelemetry();
  } catch (e) {
    log.textContent = `Error: ${e.message}`;
  }
});

// Periodic polling every 500ms
setInterval(updateTelemetry, 500);
updateTelemetry();
