"""
vision.py - Computer Vision and 3D Metric Localization
Detects objects based on color/shape, extracts their 2D image coordinates,
and deprojects them into 3D metric camera coordinates (X_c, Y_c, Z_c) in meters/millimeters.

Demonstrates how vision classifies objects into different Operation Types:
  - Red Object   -> Operation 1: Sort to Station A
  - Blue Object  -> Operation 2: Sort to Station B
  - Green Object -> Operation 3: Quality Reject Bin
"""

from typing import List, Dict
import numpy as np
import cv2

# HSV Color Ranges for segmentation
COLOR_RANGES = {
    "Red": [
        (np.array([0, 100, 70]), np.array([10, 255, 255])),
        (np.array([170, 100, 70]), np.array([180, 255, 255]))
    ],
    "Blue": [
        (np.array([100, 120, 70]), np.array([130, 255, 255]))
    ],
    "Green": [
        (np.array([35, 80, 70]), np.array([85, 255, 255]))
    ]
}

# Operation code mappings based on classification
OPERATION_MAPPINGS = {
    "Red": {"op_id": 1, "action": "Sort to Station A (Red Pallet)", "color_bgr": (0, 0, 255)},
    "Blue": {"op_id": 2, "action": "Sort to Station B (Blue Pallet)", "color_bgr": (255, 0, 0)},
    "Green": {"op_id": 3, "action": "Reject to Quality Bin", "color_bgr": (0, 255, 0)}
}


def detect_objects_and_poses(
    color_img: np.ndarray,
    depth_meters: np.ndarray,
    camera,
    min_area: int = 500
) -> List[Dict]:
    """
    Detects colored objects in the scene and calculates their 3D centroids.
    """
    hsv = cv2.cvtColor(color_img, cv2.COLOR_BGR2HSV)
    detected_objects = []

    for color_name, ranges in COLOR_RANGES.items():
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for lower, upper in ranges:
            mask = cv2.bitwise_or(mask, cv2.inRange(hsv, lower, upper))

        # Morphological filtering to eliminate noise
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < min_area:
                continue

            # Compute 2D centroid (u, v)
            M = cv2.moments(cnt)
            if M["m00"] == 0:
                continue
            u = int(M["m10"] / M["m00"])
            v = int(M["m01"] / M["m00"])

            # Bounding box
            x, y, w, h = cv2.boundingRect(cnt)

            # Robust depth measurement using median of ROI
            z_depth = camera.get_roi_depth(depth_meters, x, y, w, h)

            # Deproject (u, v, z) to 3D camera metric space (X, Y, Z) in meters
            point_3d = camera.get_3d_point(u, v, depth_val=z_depth)

            op_info = OPERATION_MAPPINGS.get(color_name, {"op_id": 0, "action": "Unknown", "color_bgr": (255, 255, 255)})

            detected_objects.append({
                "class": color_name,
                "operation_id": op_info["op_id"],
                "action": op_info["action"],
                "color_bgr": op_info["color_bgr"],
                "u": u,
                "v": v,
                "bbox": (x, y, w, h),
                "area": area,
                "point_3d": point_3d  # [X, Y, Z] in meters
            })

    return detected_objects
