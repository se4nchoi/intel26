"""
plc_controller.py - Industrial PLC Communication Interface
Supports:
  1. Mitsubishi MC Protocol (MELSEC 3E Frame Binary, Port 5010) via pymcprotocol
  2. Modbus TCP (Port 502/5020) via pymodbus
"""

from typing import Optional, Dict, List
import time

try:
    import pymcprotocol
    PYMC_AVAILABLE = True
except ImportError:
    PYMC_AVAILABLE = False

try:
    from pymodbus.client import ModbusTcpClient
    MODBUS_AVAILABLE = True
except ImportError:
    MODBUS_AVAILABLE = False


class PLCClient:
    """
    Unified PLC Client for communicating with industrial PLCs.
    Seamlessly supports Mitsubishi Q-Series (MC Protocol) and Modbus TCP.
    """

    def __init__(
        self,
        host: str = "192.168.3.150",
        port: int = 5010,
        protocol: str = "mc",  # 'mc' for Mitsubishi, 'modbus' for Modbus TCP
        timeout: float = 2.0
    ):
        self.host = host
        self.port = port
        self.protocol = protocol.lower()
        self.timeout = timeout

        self.mc_client: Optional["pymcprotocol.Type3E"] = None
        self.modbus_client: Optional["ModbusTcpClient"] = None
        self.is_connected = False

        # Internal fallback simulation registers
        self._mock_m = {0: False, 1: False, 10: False, 11: False, 12: False, 13: False}
        self._mock_d = {100: 0, 101: 0, 102: 0, 103: 0, 104: 0, 105: 0}

    def connect(self) -> bool:
        """Connects to the PLC using MC Protocol or Modbus TCP."""
        if self.protocol == "mc":
            if not PYMC_AVAILABLE:
                print("[PLCClient] pymcprotocol not installed. Using software mock.")
                self.is_connected = True
                return True
            try:
                self.mc_client = pymcprotocol.Type3E()
                self.mc_client.setaccessopt(commtype="binary")
                self.mc_client.connect(self.host, self.port)
                self.is_connected = True
                print(f"[PLCClient] SUCCESS: Connected to Mitsubishi Q-Series PLC at {self.host}:{self.port} (MC Protocol)!")
                return True
            except Exception as e:
                print(f"[PLCClient] MC Protocol connection failed: {e}. Falling back to internal mock.")
                self.is_connected = True
                self.mc_client = None
                return False
        else:
            # Modbus TCP
            if not MODBUS_AVAILABLE:
                self.is_connected = True
                return True
            try:
                self.modbus_client = ModbusTcpClient(self.host, port=self.port, timeout=self.timeout)
                if self.modbus_client.connect():
                    self.is_connected = True
                    print(f"[PLCClient] SUCCESS: Connected to Modbus PLC at {self.host}:{self.port}!")
                    return True
                else:
                    self.is_connected = True
                    self.modbus_client = None
                    return False
            except Exception as e:
                self.is_connected = True
                self.modbus_client = None
                return False

    def read_trigger(self, device_address: str = "M0") -> bool:
        """Reads the inspection trigger signal (e.g. M0)."""
        if self.mc_client:
            try:
                bits = self.mc_client.batchread_bitunits(headdevice=device_address, readsize=1)
                return bool(bits[0])
            except Exception:
                return False
        elif self.modbus_client and self.modbus_client.connected:
            res = self.modbus_client.read_coils(address=0, count=1)
            return bool(res.bits[0]) if not res.is_error() else False
        return self._mock_m.get(0, False)

    def set_trigger_simulation(self, device_address: str = "M0", state: bool = True):
        """Sets trigger state (for manual testing)."""
        if self.mc_client:
            try:
                self.mc_client.batchwrite_bitunits(headdevice=device_address, values=[1 if state else 0])
            except Exception:
                pass
        self._mock_m[0] = state

    def read_emergency_stop(self, device_address: str = "M1") -> bool:
        """Reads E-Stop flag (e.g. M1)."""
        if self.mc_client:
            try:
                bits = self.mc_client.batchread_bitunits(headdevice=device_address, readsize=1)
                return bool(bits[0])
            except Exception:
                return False
        return self._mock_m.get(1, False)

    def set_vision_busy(self, state: bool, device: str = "M10"):
        self._write_bit(device, 10, state)

    def set_vision_done(self, state: bool, device: str = "M11"):
        self._write_bit(device, 11, state)

    def set_robot_busy(self, state: bool, device: str = "M12"):
        self._write_bit(device, 12, state)

    def set_robot_done(self, state: bool, device: str = "M13"):
        self._write_bit(device, 13, state)

    def write_operation_result(
        self,
        operation_id: int,
        confidence: int,
        x_mm: int,
        y_mm: int,
        z_mm: int,
        error_code: int = 0,
        start_register: str = "D100"
    ):
        """
        Writes operation result to PLC Data Registers:
          D100: Operation ID
          D101: Confidence / Slot Index
          D102: X in mm
          D103: Y in mm
          D104: Z in mm
          D105: Error Code
        """
        def to_uint16(val: int) -> int:
            return val & 0xFFFF

        payload = [
            to_uint16(operation_id),
            to_uint16(confidence),
            to_uint16(x_mm),
            to_uint16(y_mm),
            to_uint16(z_mm),
            to_uint16(error_code)
        ]

        if self.mc_client:
            try:
                self.mc_client.batchwrite_wordunits(headdevice=start_register, values=payload)
                print(f"[PLCClient MC] Wrote {start_register}-{start_register[:1]}105 -> Op={operation_id}, X={x_mm}, Y={y_mm}, Z={z_mm}")
                return
            except Exception as e:
                print(f"[PLCClient MC] Write error: {e}")

        for i, v in enumerate(payload):
            self._mock_d[100 + i] = v

    def _write_bit(self, device: str, mock_idx: int, state: bool):
        if self.mc_client:
            try:
                self.mc_client.batchwrite_bitunits(headdevice=device, values=[1 if state else 0])
            except Exception:
                pass
        elif self.modbus_client and self.modbus_client.connected:
            self.modbus_client.write_coil(address=mock_idx, value=state)
        self._mock_m[mock_idx] = state

    def disconnect(self):
        if self.mc_client:
            try:
                self.mc_client.close()
            except Exception:
                pass
        if self.modbus_client:
            try:
                self.modbus_client.close()
            except Exception:
                pass
        self.is_connected = False
        print("[PLCClient] Disconnected.")
