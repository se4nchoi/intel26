"""
camera.py - Intel RealSense D435 Interface
Provides streaming, depth-to-color alignment, post-processing filters,
and 2D pixel to 3D metric camera coordinate deprojection.
"""

from typing import Tuple, Optional, List
import numpy as np
import cv2

try:
    import pyrealsense2 as rs
    REALSENSE_AVAILABLE = True
except ImportError:
    REALSENSE_AVAILABLE = False


class RealSenseD435:
    """
    Wrapper for the Intel RealSense D435 Depth Camera.
    
    Features:
    - Synchronized Color (RGB) and Depth streams
    - Hardware/Software Depth-to-Color Spatial Alignment (rs.align)
    - Real-time Post-Processing Filters (Decimation, Spatial, Temporal, Hole Filling)
    - 2D Pixel (u, v) + Depth (Z) to 3D Metric (X, Y, Z) deprojection using camera intrinsics
    """

    def __init__(
        self,
        width: int = 640,
        height: int = 480,
        fps: int = 30,
        align_to_color: bool = True,
        enable_filters: bool = True
    ):
        self.width = width
        self.height = height
        self.fps = fps
        self.align_to_color = align_to_color
        self.enable_filters = enable_filters

        self.pipeline: Optional["rs.pipeline"] = None
        self.config: Optional["rs.config"] = None
        self.profile: Optional["rs.pipeline_profile"] = None
        self.align: Optional["rs.align"] = None
        self.colorizer: Optional["rs.colorizer"] = None
        self.color_intrinsics = None
        self.depth_scale: float = 0.001  # Default 1mm per unit

        # Post-processing filters
        self.spatial_filter = None
        self.temporal_filter = None
        self.hole_filling_filter = None
        self.threshold_filter = None

        self._is_streaming = False
        self._is_mock = False

    def start(self) -> bool:
        """Initializes and starts the RealSense streaming pipeline."""
        if not REALSENSE_AVAILABLE:
            print("[RealSenseD435] pyrealsense2 library not available. Falling back to synthetic mock.")
            self._is_mock = True
            self._is_streaming = True
            return True

        # Attempt to start with retries for USB hub resets
        for attempt in range(1, 4):
            try:
                self.pipeline = rs.pipeline()
                self.config = rs.config()

                self.config.enable_stream(
                    rs.stream.depth, self.width, self.height, rs.format.z16, self.fps
                )
                self.config.enable_stream(
                    rs.stream.color, self.width, self.height, rs.format.bgr8, self.fps
                )

                self.profile = self.pipeline.start(self.config)
                depth_sensor = self.profile.get_device().first_depth_sensor()
                self.depth_scale = depth_sensor.get_depth_scale()

                if self.align_to_color:
                    self.align = rs.align(rs.stream.color)

                self.colorizer = rs.colorizer()
                self._init_filters()

                color_stream = self.profile.get_stream(rs.stream.color).as_video_stream_profile()
                self.color_intrinsics = color_stream.get_intrinsics()

                self._is_streaming = True
                print(f"[RealSenseD435] Started pipeline ({self.width}x{self.height} @ {self.fps}fps). Depth scale: {self.depth_scale:.6f}m")
                return True

            except Exception as e:
                if attempt < 3:
                    time.sleep(1.0)
                else:
                    print(f"[RealSenseD435] Hardware error initializing RealSense: {e}")
                    print("[RealSenseD435] Falling back to synthetic mock stream.")
                    self._is_mock = True
                    self._is_streaming = True
                    return False

    def _init_filters(self):
        """Initializes SDK post-processing filters for depth quality improvement."""
        try:
            # Spatial edge-preserving smoothing filter
            self.spatial_filter = rs.spatial_filter()
            self.spatial_filter.set_option(rs.option.filter_magnitude, 2)
            self.spatial_filter.set_option(rs.option.filter_smooth_alpha, 0.5)
            self.spatial_filter.set_option(rs.option.filter_smooth_delta, 20)
            self.spatial_filter.set_option(rs.option.holes_fill, 1)

            # Temporal persistence filter
            self.temporal_filter = rs.temporal_filter()
            self.temporal_filter.set_option(rs.option.filter_smooth_alpha, 0.4)
            self.temporal_filter.set_option(rs.option.filter_smooth_delta, 20)

            # Hole filling filter (0: fill from left, 1: fill from nearest)
            self.hole_filling_filter = rs.hole_filling_filter(1)

            # Threshold filter (0.15m to 3.0m)
            self.threshold_filter = rs.threshold_filter(0.15, 3.0)
        except Exception as e:
            print(f"[RealSenseD435] Filter initialization warning: {e}")

    def apply_depth_filters(self, depth_frame):
        """Applies spatial, temporal, and hole filling filters to raw depth frame."""
        if not self.enable_filters or self._is_mock or depth_frame is None:
            return depth_frame

        filtered = depth_frame
        try:
            if self.threshold_filter:
                filtered = self.threshold_filter.process(filtered)
            if self.spatial_filter:
                filtered = self.spatial_filter.process(filtered)
            if self.temporal_filter:
                filtered = self.temporal_filter.process(filtered)
            if self.hole_filling_filter:
                filtered = self.hole_filling_filter.process(filtered)
            return filtered.as_depth_frame()
        except Exception:
            return depth_frame

    def get_frames(
        self, apply_filters: bool = True
    ) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Optional[np.ndarray], any]:
        """
        Captures a synchronized pair of frames.
        
        Returns:
            (color_image, depth_image_meters, depth_colormap, depth_frame_object)
        """
        if self._is_mock:
            return self._generate_mock_frames()

        try:
            frames = self.pipeline.wait_for_frames(timeout_ms=400)
        except Exception:
            return None, None, None, None

        # Align depth frame to color frame if enabled
        if self.align is not None:
            aligned_frames = self.align.process(frames)
            depth_frame = aligned_frames.get_depth_frame()
            color_frame = aligned_frames.get_color_frame()
        else:
            depth_frame = frames.get_depth_frame()
            color_frame = frames.get_color_frame()

        if not depth_frame or not color_frame:
            return None, None, None, None

        # Apply post-processing filters
        if apply_filters:
            depth_frame = self.apply_depth_filters(depth_frame)

        # Convert to numpy arrays
        depth_raw = np.asanyarray(depth_frame.get_data())
        color_image = np.asanyarray(color_frame.get_data())

        # Real metric depth array in meters
        depth_in_meters = depth_raw.astype(np.float32) * self.depth_scale

        # Colorized depth for visual display
        depth_colormap_frame = self.colorizer.colorize(depth_frame)
        depth_colormap = np.asanyarray(depth_colormap_frame.get_data())

        return color_image, depth_in_meters, depth_colormap, depth_frame

    def get_3d_point(
        self, u: int, v: int, depth_frame=None, depth_val: Optional[float] = None
    ) -> Optional[List[float]]:
        """
        Deprojects 2D pixel (u, v) and its depth into 3D camera coordinates (X, Y, Z) in meters.
        
        Uses the standard pinhole camera intrinsic model:
        X = (u - c_x) * Z / f_x
        Y = (v - c_y) * Z / f_y
        Z = depth_in_meters
        """
        if u < 0 or u >= self.width or v < 0 or v >= self.height:
            return None

        # Obtain depth at pixel
        if depth_val is None:
            if depth_frame is not None and hasattr(depth_frame, "get_distance"):
                depth_val = depth_frame.get_distance(u, v)
            else:
                return None

        if depth_val <= 0.05 or depth_val > 5.0:
            # Invalid or occluded depth measurement
            return None

        if self.color_intrinsics and REALSENSE_AVAILABLE:
            # RealSense SDK exact deprojection accounting for lens distortion
            point_3d = rs.rs2_deproject_pixel_to_point(
                self.color_intrinsics, [float(u), float(v)], float(depth_val)
            )
            return [round(point_3d[0], 4), round(point_3d[1], 4), round(point_3d[2], 4)]
        else:
            # Standard pinhole model fallback
            fx = self.width * 0.95
            fy = self.width * 0.95
            cx = self.width / 2.0
            cy = self.height / 2.0
            x = (u - cx) * depth_val / fx
            y = (v - cy) * depth_val / fy
            return [round(x, 4), round(y, 4), round(depth_val, 4)]

    def get_roi_depth(
        self, depth_image_meters: np.ndarray, x: int, y: int, w: int, h: int
    ) -> float:
        """
        Computes the robust median depth of a Region Of Interest (ROI),
        filtering out zero/unmeasured depth pixels.
        """
        if depth_image_meters is None:
            return 0.0

        x_min = max(0, x)
        y_min = max(0, y)
        x_max = min(self.width, x + w)
        y_max = min(self.height, y + h)

        roi = depth_image_meters[y_min:y_max, x_min:x_max]
        valid_pixels = roi[roi > 0.05]

        if valid_pixels.size == 0:
            return 0.0
        return float(np.median(valid_pixels))

    def stop(self):
        """Stops the streaming pipeline and releases resources."""
        if self._is_streaming and self.pipeline is not None and not self._is_mock:
            try:
                self.pipeline.stop()
            except Exception as e:
                print(f"[RealSenseD435] Error stopping pipeline: {e}")
        self._is_streaming = False
        print("[RealSenseD435] Camera pipeline stopped.")

    def _generate_mock_frames(self):
        """Generates synthetic RGB-D frames for testing without physical camera."""
        color_image = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        color_image[:] = (235, 235, 235)  # Light gray table surface

        # Mock workcell table grid
        for i in range(0, self.width, 50):
            cv2.line(color_image, (i, 0), (i, self.height), (210, 210, 210), 1)
        for j in range(0, self.height, 50):
            cv2.line(color_image, (0, j), (self.width, j), (210, 210, 210), 1)

        # Mock Red block (Operation 1: Pick Type A)
        cv2.rectangle(color_image, (180, 180), (250, 250), (40, 40, 220), -1)
        cv2.putText(color_image, "Type A", (185, 220), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        # Mock Blue block (Operation 2: Pick Type B)
        cv2.rectangle(color_image, (380, 200), (450, 270), (220, 100, 40), -1)
        cv2.putText(color_image, "Type B", (385, 240), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        # Synthetic depth image (table at 0.65m, blocks at 0.60m)
        depth_in_meters = np.full((self.height, self.width), 0.65, dtype=np.float32)
        depth_in_meters[180:250, 180:250] = 0.60
        depth_in_meters[200:270, 380:450] = 0.60

        depth_colormap = cv2.applyColorMap(
            cv2.convertScaleAbs(depth_in_meters * 1000, alpha=0.08), cv2.COLORMAP_JET
        )
        return color_image, depth_in_meters, depth_colormap, None
