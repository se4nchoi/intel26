"""
robot_controller.py - Neuromeka Robot Controller with Rigid Safety Limits
Connects to Neuromeka Indy robots using IndyDCP3.
Features:
  - Strict Cartesian workspace boundaries & table collision prevention (Z floor limit)
  - Speed clamping to safe slow speeds (vel_ratio <= 10)
  - Dry-Run / Air-Run mode for safe visual trajectory verification
  - Native IndyDCP3 millimeter & degree units
  - Support for Joint Home motion (movej) and Linear motion (movel)
"""

from typing import List, Optional
import time

try:
    from neuromeka import IndyDCP3
    NEUROMEKA_AVAILABLE = True
except ImportError:
    NEUROMEKA_AVAILABLE = False


class IndyRobotController:
    """
    High-level controller for Neuromeka Indy collaborative robots with strict safety checks.
    All Cartesian coordinates are in MILLIMETERS and DEGREES [x, y, z, u, v, w].
    All Joint angles are in DEGREES [j0, j1, j2, j3, j4, j5].
    """

    def __init__(
        self,
        robot_ip: str = "192.168.3.7",
        index: int = 0,
        allow_mock_fallback: bool = True,
        camera_offset_in_base_mm: Optional[List[float]] = None,
        dry_run: bool = True,
        max_vel_ratio: int = 10,
        x_limits_mm: List[float] = [-50.0, 650.0],
        y_limits_mm: List[float] = [100.0, 650.0],
        z_limits_mm: List[float] = [150.0, 650.0],
        home_jpos: List[float] = [0.0, 0.0, -90.0, 0.0, -90.0, 0.0],
        default_tool_orientation: List[float] = [-19.52, -179.64, 90.03]
    ):
        self.robot_ip = robot_ip
        self.index = index
        self.allow_mock_fallback = allow_mock_fallback
        self.camera_offset_mm = camera_offset_in_base_mm or [232.5, 514.6, 650.0]

        # Safety parameters
        self.dry_run = dry_run
        self.max_vel_ratio = max(1, min(15, max_vel_ratio))  # Hard cap at 15% for safety
        self.x_limits = x_limits_mm
        self.y_limits = y_limits_mm
        self.z_limits = z_limits_mm  # z_limits[0] is the TABLE CRASH FLOOR LIMIT!

        self.home_jpos = list(home_jpos)
        self.default_tool_orientation = list(default_tool_orientation)

        self.indy: Optional["IndyDCP3"] = None
        self.is_connected = False
        self.is_mock = False

        self._current_pose = [232.49, 514.57, 254.19, -19.52, -179.64, 90.03]
        self._current_joints = list(self.home_jpos)
        self._gripper_state = False

    def connect(self) -> bool:
        """Establishes connection with the Neuromeka robot controller."""
        if not NEUROMEKA_AVAILABLE:
            print("[IndyRobot] neuromeka SDK not installed. Running in mock mode.")
            self.is_mock = True
            self.is_connected = True
            return True

        try:
            print(f"[IndyRobot] Connecting to Neuromeka robot at {self.robot_ip}...")
            self.indy = IndyDCP3(robot_ip=self.robot_ip, index=self.index)
            ctrl_data = self.indy.get_control_data()
            if ctrl_data and "p" in ctrl_data:
                self.is_connected = True
                self.is_mock = False
                self._current_pose = list(ctrl_data["p"])
                self._current_joints = list(ctrl_data.get("q", self.home_jpos))
                print(f"[IndyRobot] SUCCESS: Connected to Indy at {self.robot_ip}!")
                print(f"[IndyRobot] Current Pose (mm): {[round(x, 1) for x in self._current_pose]}")
                print(f"[IndyRobot] SAFETY STATUS: Dry-Run={'ON (Safe Air Moves Only)' if self.dry_run else 'OFF (PHYSICAL PICK ENABLED)'}, Max Speed={self.max_vel_ratio}%")
                return True
            else:
                raise ConnectionError("Robot controller did not return valid control telemetry.")

        except Exception as e:
            print(f"[IndyRobot] Connection failed to {self.robot_ip}: {e}")
            if self.allow_mock_fallback:
                print("[IndyRobot] Running in simulated mock mode.")
                self.is_mock = True
                self.is_connected = True
                return True
            self.is_connected = False
            return False

    def get_task_position(self) -> List[float]:
        """Returns the current end-effector Cartesian pose [x, y, z, u, v, w] in [mm, deg]."""
        if not self.is_mock and self.indy is not None:
            try:
                data = self.indy.get_control_data()
                if data and "p" in data:
                    self._current_pose = [round(float(v), 2) for v in data["p"]]
            except Exception as e:
                pass
        return list(self._current_pose)

    def get_joint_position(self) -> List[float]:
        """Returns the current joint angles [j0..j5] in degrees."""
        if not self.is_mock and self.indy is not None:
            try:
                data = self.indy.get_control_data()
                if data and "q" in data:
                    self._current_joints = [round(float(v), 2) for v in data["q"]]
            except Exception as e:
                pass
        return list(self._current_joints)

    def get_robot_status(self) -> dict:
        """Returns structured dictionary of robot state and telemetry."""
        op_state = 5
        if not self.is_mock and self.indy is not None:
            try:
                data = self.indy.get_control_data()
                op_state = data.get("op_state", 5)
            except Exception:
                pass
        return {
            "is_connected": self.is_connected,
            "is_mock": self.is_mock,
            "dry_run": self.dry_run,
            "op_state": op_state,
            "pose": self.get_task_position(),
            "joints": self.get_joint_position()
        }

    def validate_target_pose(self, pose: List[float]) -> bool:
        """
        RIGID SAFETY WORKSPACE VALIDATOR.
        Refuses to move if target violates Cartesian boundaries or table floor clearance.
        """
        x, y, z = pose[0], pose[1], pose[2]

        if not (self.x_limits[0] <= x <= self.x_limits[1]):
            print(f"[IndyRobot SAFETY ABORT] X={x:.1f}mm violates safety limits [{self.x_limits[0]}, {self.x_limits[1]}] mm!")
            return False

        if not (self.y_limits[0] <= y <= self.y_limits[1]):
            print(f"[IndyRobot SAFETY ABORT] Y={y:.1f}mm violates safety limits [{self.y_limits[0]}, {self.y_limits[1]}] mm!")
            return False

        if not (self.z_limits[0] <= z <= self.z_limits[1]):
            print(f"[IndyRobot SAFETY ABORT] Z={z:.1f}mm violates safety limits [{self.z_limits[0]}, {self.z_limits[1]}] mm! TABLE COLLISION PREVENTED.")
            return False

        return True

    def move_joint(self, jtarget: List[float], vel_ratio: Optional[int] = None) -> bool:
        """Executes a joint space motion (movej)."""
        effective_vel = min(self.max_vel_ratio, vel_ratio if vel_ratio is not None else self.max_vel_ratio)
        print(f"[IndyRobot] MoveJ -> Targets: {[round(j, 1) for j in jtarget]} deg (Vel={effective_vel}%)")

        if self.is_mock:
            self._current_joints = list(jtarget)
            time.sleep(0.4)
            return True

        try:
            self.indy.movej(jtarget=jtarget, vel_ratio=effective_vel)
            self.indy.wait_for_motion_state()
            self._current_joints = list(jtarget)
            return True
        except Exception as e:
            print(f"[IndyRobot] MoveJ error: {e}")
            return False

    def move_linear(self, target_pose: List[float], vel_ratio: Optional[int] = None) -> bool:
        """
        Executes a Cartesian linear motion (movel) with strict safety enforcement.
        target_pose: [x, y, z, u, v, w] in [mm, mm, mm, deg, deg, deg]
        """
        safe_pose = list(target_pose)

        # In dry run mode, lift Z up into the safe air zone
        if self.dry_run:
            safe_z = max(self.z_limits[0] + 80.0, safe_pose[2] + 50.0)
            safe_pose[2] = safe_z

        # Validate against hard safety boundaries
        if not self.validate_target_pose(safe_pose):
            print("[IndyRobot] Motion cancelled due to safety violation.")
            return False

        effective_vel = min(self.max_vel_ratio, vel_ratio if vel_ratio is not None else self.max_vel_ratio)
        print(f"[IndyRobot] MoveL -> Target: {[round(p, 1) for p in safe_pose[:3]]}mm (Vel={effective_vel}%)")

        if self.is_mock:
            self._current_pose = safe_pose
            time.sleep(0.4)
            return True

        try:
            self.indy.movel(ttarget=safe_pose, vel_ratio=effective_vel)
            self.indy.wait_for_motion_state()
            self._current_pose = safe_pose
            return True
        except Exception as e:
            print(f"[IndyRobot] Execution error: {e}")
            return False

    def move_home(self):
        """Moves robot to calibrated Joint Home position."""
        print("[IndyRobot] Moving to Calibrated Joint Home [0, 0, -90, 0, -90, 0]...")
        self.move_joint(self.home_jpos, vel_ratio=self.max_vel_ratio)

    def set_gripper(self, open_state: bool):
        """Actuates end-effector gripper via Digital Output (DO 0)."""
        self._gripper_state = open_state
        state_str = "OPEN" if open_state else "CLOSED (GRIP)"
        print(f"[IndyRobot] Gripper: {state_str}")

        if not self.is_mock and not self.dry_run:
            try:
                self.indy.set_do(index=0, val=open_state)
            except Exception as e:
                print(f"[IndyRobot] Gripper DO error: {e}")
        time.sleep(0.3)

    def transform_camera_to_robot(self, camera_xyz_meters: List[float]) -> List[float]:
        """
        Transforms camera space (meters) into Robot Base Frame (millimeters).
        Maintains the calibrated tool orientation [-19.52, -179.64, 90.03].
        """
        xc_mm = camera_xyz_meters[0] * 1000.0
        yc_mm = camera_xyz_meters[1] * 1000.0
        zc_mm = camera_xyz_meters[2] * 1000.0

        cam_x_base, cam_y_base, cam_z_base = self.camera_offset_mm

        xr_mm = cam_x_base - yc_mm
        yr_mm = cam_y_base + xc_mm
        zr_mm = cam_z_base - zc_mm

        # Clamp inside boundaries
        xr_mm = max(self.x_limits[0] + 10.0, min(self.x_limits[1] - 10.0, xr_mm))
        yr_mm = max(self.y_limits[0] + 10.0, min(self.y_limits[1] - 10.0, yr_mm))
        zr_mm = max(self.z_limits[0], min(self.z_limits[1], zr_mm))

        u, v, w = self.default_tool_orientation
        return [round(xr_mm, 2), round(yr_mm, 2), round(zr_mm, 2), u, v, w]

    def execute_pick_and_place(
        self,
        pick_pose: List[float],
        place_pose: List[float],
        approach_height_mm: float = 80.0
    ) -> bool:
        """Executes a safe, verified pick-and-place sequence."""
        approach_pick = list(pick_pose)
        approach_pick[2] += approach_height_mm

        approach_place = list(place_pose)
        approach_place[2] += approach_height_mm

        print(f"\n=======================================================")
        print(f" [IndyRobot] Executing Calibrated Routine")
        print(f" Mode: {'DRY-RUN (Air only, safe)' if self.dry_run else 'PHYSICAL MOTION'}")
        print(f" Pick Target:  {[round(p, 1) for p in pick_pose[:3]]} mm")
        print(f" Place Target: {[round(p, 1) for p in place_pose[:3]]} mm")
        print(f" Floor Limit:  {self.z_limits[0]} mm")
        print(f"=======================================================\n")

        # 1. Open gripper & approach pick
        self.set_gripper(open_state=True)
        if not self.move_linear(approach_pick):
            return False

        # 2. Descend to pick
        if not self.move_linear(pick_pose):
            return False

        # 3. Grip
        self.set_gripper(open_state=False)

        # 4. Retract back up to safe approach height
        if not self.move_linear(approach_pick):
            return False

        # 5. Transfer horizontally to place approach height
        if not self.move_linear(approach_place):
            return False

        # 6. Lower to place
        if not self.move_linear(place_pose):
            return False

        # 7. Release
        self.set_gripper(open_state=True)

        # 8. Retract and return home
        self.move_linear(approach_place)
        self.move_home()
        return True
