# Mitsubishi Q03UDVCPU Ethernet Setup Guide (GX Works2)

This guide walks you through connecting your **Mitsubishi Q03UDVCPU** PLC (`192.168.3.150`) to Python on your PC.

---

## ⚡ The Two Connection Options

| Feature | Option 1: MC Protocol (Recommended) | Option 2: Modbus TCP |
| :--- | :--- | :--- |
| **Ease of Setup** | **2 minutes** in GX Works2 parameters | Moderate (requires Predefined Protocol / FB) |
| **Ladder Code Required** | **None** (zero ladder logic required) | Requires ladder logic or Function Blocks |
| **Python Library** | `pymcprotocol` (already installed!) | `pymodbus` (already installed!) |
| **Direct Access** | Directly read/write `M` coils & `D` data registers | Maps to Coils and Holding Registers |

---

## 🛠️ Option 1: MC Protocol Setup in GX Works2 (Fastest & Easiest)

The built-in Ethernet port on the **Q03UDVCPU** has native hardware support for **MC Protocol (MELSEC Communication Protocol)**. This lets your Python script read and write PLC bits (`M0`, `M1`) and data registers (`D100`, `D101`) directly without writing a single line of ladder code!

### Step 1: Open PLC Parameters in GX Works2
1. Open your project in **GX Works2**.
2. In the left navigation tree (Project tab), expand:
   `Parameter` $\rightarrow$ double-click **`PLC Parameter`**.
3. In the parameter dialog, select the **`Built-in Ethernet Port Setting`** tab.

```
+-------------------------------------------------------------------------------+
| Q Parameter Setting - Built-in Ethernet Port Setting                          |
+-------------------------------------------------------------------------------+
| IP Address:            [ 192 . 168 . 3 . 150 ]                                |
| Subnet Mask:           [ 255 . 255 . 255 . 0 ]                                |
| Default Gateway:       [ 192 . 168 . 3 . 1   ]                                |
|                                                                               |
| Communication Data Code: (*) Binary Code     ( ) ASCII Code                   |
|                                                                               |
|                         [ Open Setting ]  <--- Click this button!             |
+-------------------------------------------------------------------------------+
```

### Step 2: Configure Open Setting
Click the **`Open Setting`** button. Configure Line 1 as follows:

| Column | Recommended Value | Description |
| :--- | :--- | :--- |
| **Protocol** | **`TCP`** | Standard reliable Ethernet transport |
| **Open System** | **`MC Protocol`** | Native Mitsubishi protocol |
| **Fixed Buffer** | Send | Default |
| **Fixed Buffer Communication**| Procedure Exist | Default |
| **Pairing Open** | Disable | Default |
| **Existence Confirmation** | Confirm | Automatically detects disconnections |
| **Host Station Port No. (DEC)**| **`5000`** | Port number Python will connect to |

Click **`End`** to save the table, then click **`Check`** and **`End`** on the main parameter window.

### Step 3: Write Parameters to PLC & Reset
1. In the top menu, go to **`Online` $\rightarrow$ `Write to PLC...`**.
2. Check **`PLC/Network Parameters`** (and program if modified).
3. Click **`Execute`**.
4. Once written, **toggle the PLC RUN/STOP switch to STOP, then RESET, then back to RUN** (or cycle power) to apply the new Ethernet settings.

---

## 🐍 Testing the Connection from Python

We created a test script [examples/05_mitsubishi_plc_test.py](file:///e:/_se4nchoi/intel26/advanced_robot_programming/examples/05_mitsubishi_plc_test.py):

```python
import pymcprotocol

# Connect to Q03UDVCPU at 192.168.3.150 on port 5000 (3E Frame Binary)
pymc = pymcprotocol.Type3E()
pymc.connect("192.168.3.150", 5000)

# 1. Read trigger bit M0 (Inspection Trigger from conveyor sensor)
m0_val = pymc.batchread_bitunits(headdevice="M0", readsize=1)[0]
print(f"Part Sensor M0: {m0_val}")

# 2. Write Operation ID to Data Register D100 (1: Pallet, 2: Magazine)
pymc.batchwrite_wordunits(headdevice="D100", values=[1])

# 3. Write target coordinates to D102, D103, D104 (X, Y, Z in mm)
pymc.batchwrite_wordunits(headdevice="D102", values=[232, 514, 254])

# 4. Pulse Vision Done bit M11
pymc.batchwrite_bitunits(headdevice="M11", values=[1])
```

---

## 🔄 Option 2: Modbus TCP (If Strictly Required by Factory Spec)

If your facility requires pure Modbus TCP (Port 502) rather than MC Protocol:
1. In GX Works2, under **`Built-in Ethernet Port Setting`** $\rightarrow$ **`Open Setting`**:
   - Set Protocol: `TCP`
   - Open System: `Predefined Protocol` (or `Unpassive`)
   - Port: `502`
2. Download the **Mitsubishi Modbus/TCP Server Function Block (FB)** from the Mitsubishi Electric FA portal (`M+QCPU_ModbusTCP_Server_00A`).
3. Add the FB to your ladder logic and map holding registers to your desired `D` registers (e.g. `D100` to `D110`).
