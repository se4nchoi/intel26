# How the Intel RealSense D435 Depth Camera Works

This guide explains the optical physics, hardware architecture, depth computation formulas, and computer vision mathematics behind the **Intel RealSense D435** depth camera.

---

## 1. Physical Hardware & Architecture

The RealSense D435 utilizes **Active Infrared (IR) Stereo Vision**. Inside the camera module are four primary optical elements:

```
+-----------------------------------------------------------------------+
|  [Left IR Camera]    [IR Projector]    [RGB Sensor]   [Right IR Camera]  |
+-----------------------------------------------------------------------+
        |<---------------- Baseline B (~50 mm) ---------------->|
```

1. **Left & Right Infrared Imagers:**
   - A matched stereo pair of global shutter IR sensors.
   - They capture the scene in the near-infrared spectrum (~850nm).
   - Distance between them is the **Stereo Baseline ($B$)**, approximately $50\text{ mm}$.
2. **Infrared Pattern Projector:**
   - Emits an invisible, non-uniform dot pattern onto the physical environment.
   - **Why?** Classic stereo vision fails on textureless, uniform surfaces (e.g. a plain white wall, a smooth plastic tray, a metallic plate) because distinct feature points cannot be matched. The IR projector artificially projects high-contrast texture onto these surfaces.
3. **RGB Color Sensor:**
   - Standard rolling shutter RGB sensor (up to 1920x1080 @ 30fps) for visible light imaging.
4. **Intel RealSense Vision Processor D4 ASIC:**
   - A dedicated onboard hardware chip inside the camera that computes disparity correlations in real time, offloading CPU processing.

---

## 2. Mathematical Principle: Stereo Triangulation & Disparity

Stereo vision determines depth by identifying the same physical point in both the Left and Right camera images and measuring their horizontal pixel shift, termed **Disparity ($d$)**.

```
                   Target Point P (X, Y, Z)
                            /\
                           /  \
                          /    \
                         /      \
                        /        \
                       /          \
                      /            \
          Left Image Plane      Right Image Plane
             [ . x_l ]               [ x_r . ]
                 \                      /
                  \                    /
              Left Optical        Right Optical
                 Center               Center
                    |<--- Baseline B --->|
```

### The Fundamental Depth Equation:
$$Z = \frac{f \cdot B}{d}$$

Where:
- $Z$: Perpendicular depth (distance from camera focal plane to target) in meters.
- $f$: Focal length of the IR lenses (in pixels).
- $B$: Physical baseline distance between left and right IR sensors ($\approx 0.050\text{ m}$).
- $d$: Disparity in pixels ($d = x_{\text{left}} - x_{\text{right}}$).

### Key Insights from the Formula:
1. **Inverse Relationship ($Z \propto \frac{1}{d}$):**
   - Objects close to the camera produce large disparities (hundreds of pixels).
   - Faraway objects produce very small disparities (approaching zero).
2. **Depth Precision Degradation ($\Delta Z \propto Z^2$):**
   The error in depth $\Delta Z$ for a 1-pixel disparity error is:
   $$\Delta Z \approx \frac{Z^2}{f \cdot B} \cdot \Delta d$$
   At $0.5\text{ m}$, depth precision is millimeter-level ($\approx 1\text{ mm}$ to $2\text{ mm}$).
   At $3.0\text{ m}$, depth noise increases to tens of millimeters ($\approx 20\text{ mm}$ to $40\text{ mm}$).
3. **Minimum Working Distance ($Z_{\min}$):**
   For the D435, $Z_{\min} \approx 0.175\text{ m}$ ($17.5\text{ cm}$). Any object closer than this falls outside the overlapping field-of-view of the two IR cameras, resulting in blind spots (zero depth).

---

## 3. Depth-to-Color Alignment (`rs.align`)

The RGB sensor and the IR stereo pair are physically separated by several centimeters along the camera casing. This causes two major differences:
1. **Different Fields of View (FOV):**
   - D435 Depth FOV: $86^\circ \times 57^\circ$ (Wide FOV)
   - D435 RGB FOV: $69^\circ \times 42^\circ$
2. **Different Optical Centers:**
   A pixel at coordinate $(320, 240)$ in the depth image does **not** correspond to pixel $(320, 240)$ in the RGB image.

### How Alignment Works:
The RealSense SDK provides `rs.align(rs.stream.color)`:
1. It reads the factory-calibrated extrinsic matrix (rotation $R$ and translation $T$ between the IR sensor and RGB sensor).
2. For each depth pixel, it reprojects the $(u_d, v_d, Z)$ point into the 3D optical frame of the RGB sensor.
3. It projects that 3D point into the 2D pixel grid of the RGB camera $(u_c, v_c)$.
4. The output is an aligned depth map where pixel $(u, v)$ in color matches pixel $(u, v)$ in depth exactly.

---

## 4. Converting 2D Pixels to 3D Metric Coordinates (Deprojection)

Once depth is aligned to color, you can convert any 2D bounding box or centroid $(u, v)$ into 3D metric camera coordinates $(X_c, Y_c, Z_c)$ using the **Pinhole Camera Model**:

$$X_c = \frac{(u - c_x) \cdot Z}{f_x}$$
$$Y_c = \frac{(v - c_y) \cdot Z}{f_y}$$
$$Z_c = Z$$

Where:
- $(c_x, c_y)$: Principal point (optical center of the lens in pixels).
- $(f_x, f_y)$: Focal length in pixel units.
- $Z$: Depth value measured by the sensor (in meters).

In the RealSense SDK, this is handled in one call:
```python
point_3d = rs.rs2_deproject_pixel_to_point(color_intrinsics, [u, v], depth_in_meters)
# Returns [X, Y, Z] in meters relative to the camera lens!
```

---

## 5. RealSense Post-Processing Filters

Raw stereo depth frames can contain noise, missing pixels (occlusion holes), or shimmering edges. The SDK provides hardware-optimized filters:

1. **Threshold Filter:**
   - Cuts off depth data outside a desired working zone (e.g. ignore everything beyond $1.5\text{ m}$ to isolate the workcell table).
2. **Decimation Filter:**
   - Sub-samples the depth map (reduces resolution by $2\times$ or $4\times$) while increasing signal-to-noise ratio.
3. **Spatial Filter (Edge-Preserving Smoothing):**
   - Applies an intelligent smoothing kernel that smooths flat surfaces without blurring sharp object edges.
4. **Temporal Filter (Time-Domain Smoothing):**
   - Blends depth values across consecutive frames using an exponential moving average to eliminate flickering.
5. **Hole Filling Filter:**
   - Interpolates missing depth pixels from neighboring valid surface pixels.
