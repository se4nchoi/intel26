# Understanding Modbus: The Universal Language of Industrial PLCs

If you have never worked with **Modbus** before, don't worry! It is one of the simplest, oldest, and most reliable protocols in industrial automation.

---

## 1. What is Modbus?

In a factory, devices made by different manufacturers (a Siemens or LS Electric PLC, a Neuromeka robot, a Cognex or Intel camera system, a conveyor motor driver) need to talk to each other.

**Modbus** is an open industrial communication protocol created in 1979. Think of it as a **shared spreadsheet in the PLC's memory**:
- One machine writes a number into a specific "cell" (register).
- Another machine reads that number and reacts to it.

When run over an Ethernet network cable, it is called **Modbus TCP** (standard port: `502`).

---

## 2. Client vs Server (Master vs Slave)

In Modbus TCP:
- **Server (Slave):** The device holding the data memory (usually the **PLC**). It sits and listens for incoming requests.
- **Client (Master):** The device initiating requests (usually the **PC / Vision System** or HMI screen). It connects, reads registers, or writes commands into the PLC.

```
+------------------------------------+             +------------------------------------+
|         PC / Vision System         |   Modbus    |             PLC Server             |
|          (Modbus Client)           | ----------> |       (Modbus TCP on Port 502)     |
|  "Hey PLC, set Coil 11 (Done)=1!"  |    TCP      | Holds Memory Tables (Coils & Regs) |
+------------------------------------+             +------------------------------------+
```

---

## 3. The 4 Fundamental Modbus Memory Tables

Modbus memory is divided into just 4 tables based on **data size** (1-bit boolean vs 16-bit number) and **access permissions** (Read-Only vs Read/Write):

| Memory Type | Size | Access | Typical Real-World Use Case |
| :--- | :--- | :--- | :--- |
| **Coil** | **1-bit** (ON / OFF) | **Read / Write** | Turning on a motor, opening a pneumatic valve, signaling a Handshake flag (`Trigger`, `Vision_Busy`, `Robot_Done`). |
| **Discrete Input** | **1-bit** (ON / OFF) | **Read-Only** | Physical hardware sensors wired to PLC inputs (e.g. photoelectric part sensor, safety gate switch). |
| **Holding Register** | **16-bit** (0 to 65535) | **Read / Write** | Recipe/Operation IDs, target coordinates ($X, Y, Z$ in millimeters), speed settings, error codes. |
| **Input Register** | **16-bit** (0 to 65535) | **Read-Only** | Analog sensors wired to PLC (temperature, pressure, conveyor encoder tick count). |

---

## 4. How the Robot-Vision Handshake Works with Modbus

Imagine a conveyor with a photoelectric sensor and our RealSense vision cell:

```
[PLC Memory]
Coil 0:   [ Trigger ]       <--- PLC turns ON (1) when part arrives at camera
Coil 10:  [ Vision_Busy ]   <--- PC turns ON (1) while processing camera image
Coil 11:  [ Vision_Done ]   <--- PC pulses ON (1) when detection finishes
Reg 100:  [ Operation_ID ]  <--- PC writes '1' for Red part, '2' for Blue part
Reg 102:  [ Pick_X_mm ]     <--- PC writes 350 mm
Reg 103:  [ Pick_Y_mm ]     <--- PC writes -180 mm
Reg 104:  [ Pick_Z_mm ]     <--- PC writes 150 mm
```

### The Step-by-Step Cycle:
1. The **PLC** detects a part on the conveyor $\rightarrow$ writes `1` to **Coil 0**.
2. The **Python script** reads Coil 0:
   ```python
   trigger = client.read_coils(address=0, count=1).bits[0]
   if trigger:
       # Step 2: Set Vision Busy
       client.write_coil(address=10, value=True)
       
       # Step 3: Run OpenCV on RealSense frame
       obj_type, x, y, z = inspect_part()
       
       # Step 4: Write Operation and Coordinates to PLC
       client.write_registers(address=100, values=[obj_type, 95, x, y, z])
       
       # Step 5: Signal Done
       client.write_coil(address=10, value=False) # Busy OFF
       client.write_coil(address=11, value=True)  # Done ON
   ```
3. The **Robot** picks the object based on the recognized type.
4. When finished, the robot or PC turns `Done = OFF`, and the cycle is ready for the next part!

---

## 5. Python Example with `pymodbus`

Connecting and reading from a PLC takes only 5 lines of Python:

```python
from pymodbus.client import ModbusTcpClient

# 1. Connect to the PLC's IP address
client = ModbusTcpClient(host="192.168.3.150", port=502)
client.connect()

# 2. Read a 1-bit boolean switch (Coil 0)
result = client.read_coils(address=0, count=1)
sensor_state = result.bits[0]
print(f"Part Sensor State: {sensor_state}")

# 3. Write a 16-bit number to Holding Register 100
client.write_register(address=100, value=1)  # Set Operation ID = 1

client.close()
```
