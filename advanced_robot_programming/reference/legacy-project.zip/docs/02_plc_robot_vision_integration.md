# PLC, Depth Camera, and Robot Integration Architecture

This guide explains how to connect an **Industrial PLC**, an **Intel RealSense D435** depth camera, and a **Neuromeka Indy** robot to form an intelligent automated workcell.

---

## 1. System Topology & Communication

In a modern industrial robot cell, a **Central Edge PC** runs the vision intelligence and bridges the PLC and the Robot Controller:

```
                          +-------------------------+
                          |   Intel RealSense D435  |
                          |      (USB 3.0 Type-C)   |
                          +------------+------------+
                                       |
                                       v (RGB-D Video Stream)
+-------------------+     Ethernet     +-------------------------+     Ethernet     +-------------------+
|  Industrial PLC   | <--------------> |      Workcell PC        | <--------------> | Neuromeka STEP    |
| (Siemens/LS/etc.) |   (Modbus TCP)   | (Python 3.12 / OpenCV)  |   (IndyDCP3/TCP) | Robot Controller  |
+-------------------+                  +-------------------------+                  +---------+---------+
        |                                                                                     |
        v                                                                                     v
[Sensors, Conveyor,                                                                   [Indy7 / IndyRP2]
 E-Stop, Safety Gate]                                                                  6-DOF Arm & Tool
```

### Protocol Summary:
- **Camera $\rightarrow$ PC:** USB 3.0 high-bandwidth data stream using `pyrealsense2`.
- **PC $\leftrightarrow$ PLC:** Modbus TCP (standard industrial fieldbus protocol over Ethernet via `pymodbus`).
- **PC $\leftrightarrow$ Robot:** Neuromeka `IndyDCP3` protocol over TCP/IP (port 6066/gRPC).

---

## 2. The Industrial Handshake State Machine

To prevent collisions, race conditions, or dropped parts, the PLC, Vision system, and Robot communicate via strict digital handshake signals:

```
[PLC]                       [Vision (PC)]                     [Robot]
  |                               |                              |
  |--- 1. Part Arrived (Coil 0)-> |                              |
  |    (Trigger Inspection)       |                              |
  |                               |-- 2. Capture & Classify -->  |
  |                               |   (RealSense D435 + OpenCV)  |
  |                               |                              |
  |<- 3. Operation ID & Pose -----|                              |
  |<- 4. Vision Done (Coil 11) ---|                              |
  |                               |                              |
  |                               |--- 5. Command MoveL/Pick --->|
  |<- 6. Robot Busy (Coil 12) ----|                              |
  |                               |                              |-- 6. Execute Pick & Place
  |                               |                              |
  |<- 7. Robot Done (Coil 13) ----|                              |<-- 7. Motion Complete
  |                               |                              |
  |-- 8. Reset Cycle ------------>|                              |
  v                               v                              v
```

### Handshake Signal Specification:

| Device | Signal Name | Type / Address | Description |
| :--- | :--- | :--- | :--- |
| **PLC $\rightarrow$ PC** | `Trigger_Inspection` | Coil `0` | Set to `1` when a photoelectric sensor detects a part stopped in the camera view. |
| **PLC $\rightarrow$ PC** | `Emergency_Stop` | Coil `1` | Set to `1` if safety light curtain is broken or E-stop button is depressed. |
| **PC $\rightarrow$ PLC** | `Vision_Busy` | Coil `10` | Set to `1` while camera is acquiring frames and OpenCV is running. |
| **PC $\rightarrow$ PLC** | `Vision_Done` | Coil `11` | Pulsed to `1` when classification and 3D coordinates are published. |
| **PC $\rightarrow$ PLC** | `Robot_Busy` | Coil `12` | Set to `1` while the robot arm is actively in motion. |
| **PC $\rightarrow$ PLC** | `Robot_Done` | Coil `13` | Pulsed to `1` when pick, transfer, and place cycle finishes. |
| **PC $\rightarrow$ PLC** | `Operation_ID` | Reg `100` | `1` = Station A, `2` = Station B, `3` = Reject Bin, `0` = Fault. |
| **PC $\rightarrow$ PLC** | `Target_X_mm` | Reg `102` | Real-world pick target $X$ coordinate in millimeters. |
| **PC $\rightarrow$ PLC** | `Target_Y_mm` | Reg `103` | Real-world pick target $Y$ coordinate in millimeters. |
| **PC $\rightarrow$ PLC** | `Target_Z_mm` | Reg `104` | Real-world pick target $Z$ coordinate in millimeters. |

---

## 3. Hand-Eye Calibration (Eye-to-Hand)

The camera measures coordinates in its own optical frame $(X_c, Y_c, Z_c)$. The robot requires coordinates in its base frame $(X_r, Y_r, Z_r)$.

```
   [Camera Optical Frame]
       +Z_c points toward table
       +X_c points right
       +Y_c points down
            \
             \  Transformation: T_base_to_camera
              v
   [Robot Base Frame]
       +X_r points forward
       +Y_r points left
       +Z_r points upward
```

### Coordinate Transformation Formula:
$$\begin{bmatrix} X_r \\ Y_r \\ Z_r \\ 1 \end{bmatrix} = \begin{bmatrix} R_{11} & R_{12} & R_{13} & T_x \\ R_{21} & R_{22} & R_{23} & T_y \\ R_{31} & R_{32} & R_{33} & T_z \\ 0 & 0 & 0 & 1 \end{bmatrix} \begin{bmatrix} X_c \\ Y_c \\ Z_c \\ 1 \end{bmatrix}$$

For a fixed overhead camera pointing downward:
- $X_r = X_{\text{camera\_offset}} - Y_c$
- $Y_r = Y_{\text{camera\_offset}} + X_c$
- $Z_r = Z_{\text{camera\_offset}} - Z_c$

---

## 4. Selecting Different Operations from Image Recognition

When an object is detected, the image recognition step computes:
1. **Class Label:** Color (Red, Blue, Green), Shape (Circle, Square), or Barcode / AprilTag.
2. **Geometric Dimensions:** Width, length, orientation angle $\theta$.
3. **Quality Status:** Defect detected, scratch, missing component, or dimensional tolerance exceeded.

Based on these recognition results, the program dynamically chooses an **Operation Profile**:

```python
if object_class == "Type_A_Part":
    op_id = 1
    destination = PALLET_A_COORDINATES
elif object_class == "Type_B_Part":
    op_id = 2
    destination = PALLET_B_COORDINATES
elif is_defective(object):
    op_id = 3
    destination = REJECT_BIN_COORDINATES
```

The operation ID is communicated to the PLC so the PLC can update shift counters, trigger pneumatic ejectors, or index conveyors, while the Neuromeka robot receives the target pose to execute the corresponding motion routine.
